# EFN: Experience Feedback Network

Thank you for reviewing our paper! This repository contains the implementation of our submission "Dejavu: Towards Experience Feedback Learning for Embodied Intelligence". Currently this is the beta version and we will make it publicly available after publication.

## Layout

- `efn/`  
  Core Python package that implements the Experience Feedback Network, training loops,
  data loading utilities and experiment definitions.

- `scripts/`  
  Entry-point scripts and helper shell scripts used to launch experiments, evaluation,
  and log processing.

- `configs/`  
  Configuration files (YAML/JSON) that specify environments, model hyperparameters,
  and training schedules.

- `notebooks/`  
  Jupyter notebooks for small-scale experiments, debugging, and visualization.

- `assets/`  
  Auxiliary files such as example data, logs, figures, and any remaining resources
  needed to reproduce the experiments.

## Usage

1. Install dependencies into a Python environment that matches the versions used in the paper.
2. Add the repository root to your `PYTHONPATH` or install `efn` as an editable package:
   ```bash
   pip install -e .
   ```
3. Use the scripts under `scripts/` together with the configuration files in `configs/`
   to run training and evaluation. Typical usage looks like:
   ```bash
   python scripts/train_efn.py --config configs/libero_example.yaml
   ```


