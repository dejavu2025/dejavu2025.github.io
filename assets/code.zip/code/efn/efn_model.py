from typing import Optional, Tuple
from einops import rearrange, repeat
import torch
import torch.nn as nn
import torch.nn.functional as F
import time

# RMSNorm -- Better, simpler alternative to LayerNorm
class RMSNorm(nn.Module):
    def __init__(self, dim: int, eps: float = 1e-8) -> None:
        super().__init__()
        self.scale, self.eps = dim**-0.5, eps
        self.g = nn.Parameter(torch.ones(dim))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        norm = torch.norm(x, dim=-1, keepdim=True) * self.scale
        return x / norm.clamp(min=self.eps) * self.g

# SwishGLU -- A Gated Linear Unit (GLU) with the Swish activation; always better than GELU MLP!
class SwishGLU(nn.Module):
    def __init__(self, in_dim: int, out_dim: int) -> None:
        super().__init__()
        self.act, self.project = nn.SiLU(), nn.Linear(in_dim, 2 * out_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        projected, gate = self.project(x).tensor_split(2, dim=-1)
        return projected * self.act(gate)


# As defined in Set Transformers () -- basically the above, additionally taking in
# a set of $k$ learned "seed vectors" that are used to "pool" information.
class MAPAttention(nn.Module):
    def __init__(self, embed_dim: int, n_heads: int) -> None:
        """Multi-Input Multi-Headed Attention Operation"""
        super().__init__()
        assert embed_dim % n_heads == 0, "`embed_dim` must be divisible by `n_heads`!"
        self.n_heads, self.scale = n_heads, (embed_dim // n_heads) ** -0.5

        # Projections (no bias) --> separate for Q (seed vector), and KV ("pool" inputs)
        self.q, self.kv = nn.Linear(embed_dim, embed_dim, bias=False), nn.Linear(embed_dim, 2 * embed_dim, bias=False)
        self.proj = nn.Linear(embed_dim, embed_dim)

    def forward(self, seed: torch.Tensor, x: torch.Tensor, attention_mask = None) -> torch.Tensor:
        (B_s, K, C_s), (B_x, N, C_x) = seed.shape, x.shape
        assert C_s == C_x, "Seed vectors and pool inputs must have the same embedding dimensionality!"

        # Project Seed Vectors to `queries`
        q = self.q(seed).reshape(B_s, K, self.n_heads, C_s // self.n_heads).permute(0, 2, 1, 3)
        kv = self.kv(x).reshape(B_x, N, 2, self.n_heads, C_x // self.n_heads).permute(2, 0, 3, 1, 4)
        k, v = kv.unbind(0)

        # Attention --> compute weighted sum over values!
        scores = q @ (k.transpose(-2, -1) * self.scale)
        # print(scores.shape)
        if attention_mask is not None:
            attention_mask = (
                attention_mask[None, None, :, :].repeat(1, self.n_heads, 1, 1) #.flatten(0, 1)
            )
            scores.masked_fill_(attention_mask == 0, float("-inf"))
        attn = scores.softmax(dim=-1)
        

        vals = (attn @ v).transpose(1, 2).reshape(B_s, K, C_s)

        # Project back to `embed_dim`
        return self.proj(vals)

class MAPBlock(nn.Module):
    def __init__(
        self,
        n_latents: int,
        vis_dim: int, 
        embed_dim: int,
        n_heads: int,
        mlp_ratio: float = 4.0,
        do_rms_norm: bool = True,
        do_swish_glu: bool = True,
    ) -> None:
        """Multiheaded Attention Pooling Block -- note that for MAP, we adopt earlier post-norm conventions."""
        super().__init__()
        self.n_latents, self.embed_dim, self.n_heads = n_latents, embed_dim, n_heads

        # Projection Operator
        self.projection = nn.Linear(vis_dim, self.embed_dim)

        # Initialize Latents
        self.latents = nn.Parameter(torch.zeros(self.n_latents, self.embed_dim), requires_grad=True)
        nn.init.normal_(self.latents, std=0.02)

        # Custom MAP Attention (seed, encoder outputs) -> seed
        self.attn_norm = RMSNorm(self.embed_dim) if do_rms_norm else nn.LayerNorm(self.embed_dim, eps=1e-6)
        self.attn = MAPAttention(self.embed_dim, n_heads=self.n_heads)

        # Position-wise Feed-Forward Components
        self.mlp_norm = RMSNorm(self.embed_dim) if do_rms_norm else nn.LayerNorm(self.embed_dim, eps=1e-6)
        self.mlp = nn.Sequential(
            # Handle SwishGLU vs. GELU MLP...
            (
                SwishGLU(self.embed_dim, int(mlp_ratio * self.embed_dim))
                if do_swish_glu
                else nn.Sequential(nn.Linear(self.embed_dim, int(mlp_ratio * self.embed_dim)), nn.GELU())
            ),
            nn.Linear(int(mlp_ratio * self.embed_dim), self.embed_dim),
        )

    def forward(self, x: torch.Tensor, mask = None, init_embed = None) -> torch.Tensor:
        latents = repeat(self.latents, "n_latents d -> bsz n_latents d", bsz=x.shape[0])
        latents = latents + init_embed.unsqueeze(1) if init_embed is not None else latents
        latents = self.attn_norm(latents + self.attn(latents, self.projection(x), mask))
        latents = self.mlp_norm(latents + self.mlp(latents))
        return latents.squeeze(dim=1)


class LayerNormFp32(nn.LayerNorm):
    """ bf16/fp16  LayerNorm fp32  dtype"""
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return super().forward(x.float()).type_as(x)


def make_mlp(dims, act=nn.GELU, last_act=None):
    layers = []
    for i in range(len(dims) - 1):
        layers.append(nn.Linear(dims[i], dims[i + 1]))
        if i < len(dims) - 2:
            layers.append(act())
        elif last_act is not None:
            layers.append(last_act())
    return nn.Sequential(*layers)


#  ->  latent

class EFNPolicyNetwork(nn.Module):
    """
    Query:    4  latent token
    Context: [(4) + (4) +  latent(4)]   12  token
    Cross-Attn -> Tiny Transformer -> Δlatent
    """
    def __init__(
        self,
        vis_dim: int = 4096,          
        token_dim: int = 4096,       
        n_visual_latents: int = 4,     
        embed_dim: int = 1024,         
        nhead: int = 16,
        ff_dim: int = 4096,
        num_layers: int = 2,
        dropout: float = 0.1,
        residual_clip: float = 1.0     # tanh 
    ):
        super().__init__()
        self.residual_clip = residual_clip

        # / 256×4096 -> 4×embed_dim
        self.visual_pool_cur = MAPBlock(
            n_latents=n_visual_latents,
            vis_dim=vis_dim,
            embed_dim=embed_dim,
            n_heads=max(1, embed_dim // 64)
        )
        self.visual_pool_exp = MAPBlock(
            n_latents=n_visual_latents,
            vis_dim=vis_dim,
            embed_dim=embed_dim,
            n_heads=max(1, embed_dim // 64)
        )

        # latent  embed_dim/
        self.token_in_cur = nn.Linear(token_dim, embed_dim)
        self.token_in_exp = nn.Linear(token_dim, embed_dim)

        # Cross-Attn: Q= latent(4)K/V=(12)
        self.q_ln = LayerNormFp32(embed_dim)
        self.k_ln = LayerNormFp32(embed_dim)
        self.v_ln = LayerNormFp32(embed_dim)
        self.cross_attn = nn.MultiheadAttention(
            embed_dim=embed_dim, num_heads=nhead, dropout=dropout, batch_first=True
        )
        self.cross_ff = nn.Sequential(
            LayerNormFp32(embed_dim),
            nn.Linear(embed_dim, ff_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(ff_dim, embed_dim),
        )

        #  Transformer  4  token
        enc_layer = nn.TransformerEncoderLayer(
            d_model=embed_dim, nhead=nhead,
            dim_feedforward=ff_dim, dropout=dropout,
            batch_first=True, norm_first=True, activation="gelu"
        )
        self.encoder = nn.TransformerEncoder(enc_layer, num_layers=num_layers)

        #  4096 tanh “”
        self.out_ln = LayerNormFp32(embed_dim)
        self.proj_out = make_mlp([embed_dim, ff_dim, token_dim], act=nn.GELU, last_act=nn.Tanh)

    def forward(
        self,
        latent_tokens_cur: torch.Tensor,   # (B, 4, 4096)
        visual_embed_cur: torch.Tensor,    # (B, 256, 4096)
        latent_tokens_exp: torch.Tensor,   # (B, 4, 4096)
        visual_embed_exp: torch.Tensor,    # (B, 256, 4096)
    ) -> torch.Tensor:
        assert latent_tokens_cur.dim() == 3 and latent_tokens_cur.size(1) == 4
        assert latent_tokens_exp.dim() == 3 and latent_tokens_exp.size(1) == 4
        assert visual_embed_cur.dim() == 3 and visual_embed_cur.size(1) == 256
        assert visual_embed_exp.dim() == 3 and visual_embed_exp.size(1) == 256

        #  (B, 4, E)
        vis_ctx_cur = self.visual_pool_cur(visual_embed_cur)  # (B, 4, E)
        vis_ctx_exp = self.visual_pool_exp(visual_embed_exp)  # (B, 4, E)

        # latent  embed_dim
        q_cur = self.token_in_cur(latent_tokens_cur)          # (B, 4, E)
        k_exp = self.token_in_exp(latent_tokens_exp)          # (B, 4, E)

        #  K/V: [4, 4, latent4] -> (B, 12, E)
        kv = torch.cat([vis_ctx_cur, vis_ctx_exp, k_exp], dim=1)  # (B, 12, E)

        # Cross-AttnQ= latentK/V=
        q = self.q_ln(q_cur)
        k = self.k_ln(kv)
        v = self.v_ln(kv)
        x, _ = self.cross_attn(q, k, v)                        # (B, 4, E)

        # Cross-FF + 
        x = x + self.cross_ff(x)

        #  Transformer 4  token 
        x = self.encoder(x)                                    # (B, 4, E)
        x = self.out_ln(x)

        #  4096 tanh  residual
        residual = self.proj_out(x).clamp_(-1.0, 1.0)          # (B, 4, 4096) in [-1, 1]
        if self.residual_clip is not None:
            residual = self.residual_clip * residual
        return residual



class EFNCriticNetwork(nn.Module):
    """
    
    / 1  MAP latent/ latent  MLP
    """
    def __init__(
        self,
        vis_dim: int = 4096,
        token_dim: int = 4096,
        embed_dim: int = 1024,
        ff_dim: int = 2048
    ):
        super().__init__()
        self.visual_pool_cur = MAPBlock(
            n_latents=1, vis_dim=vis_dim, embed_dim=embed_dim, n_heads=max(1, embed_dim // 64)
        )
        self.visual_pool_exp = MAPBlock(
            n_latents=1, vis_dim=vis_dim, embed_dim=embed_dim, n_heads=max(1, embed_dim // 64)
        )
        self.token_reduce_cur = nn.Linear(token_dim, embed_dim)
        self.token_reduce_exp = nn.Linear(token_dim, embed_dim)

        in_dim = embed_dim * 4  # [v_cur, v_exp, t_cur, t_exp]
        self.ln = LayerNormFp32(in_dim)
        self.mlp = make_mlp([in_dim, ff_dim, ff_dim, 1], act=nn.GELU)

    def forward(
        self,
        latent_tokens_cur: torch.Tensor,  # (B, 4, 4096)
        visual_embed_cur: torch.Tensor,   # (B, 256, 4096)
        latent_tokens_exp: torch.Tensor,  # (B, 4, 4096)
        visual_embed_exp: torch.Tensor,   # (B, 256, 4096)
    ) -> torch.Tensor:
        #  (B, 1, E) -> squeeze
        v_cur = self.visual_pool_cur(visual_embed_cur)         # (B, E)
        v_exp = self.visual_pool_exp(visual_embed_exp)         # (B, E)

        # latent 4  token 
        t_cur = self.token_reduce_cur(latent_tokens_cur.mean(dim=1))  # (B, E)
        t_exp = self.token_reduce_exp(latent_tokens_exp.mean(dim=1))  # (B, E)

        x = torch.cat([v_cur, v_exp, t_cur, t_exp], dim=-1)    # (B, 4E)
        x = self.ln(x)
        value = self.mlp(x)                                    # (B, 1)
        return value



class EFNModel(nn.Module):
    """
    
    - compute_residual(latent_cur, visual_cur, latent_exp, visual_exp) -> residual
    - refine_latent(latent_cur, visual_cur, latent_exp, visual_exp) -> latent_cur + residual
    - forward(...) -> (residual, value)
    """
    def __init__(
        self,
        vis_dim: int = 4096,
        token_dim: int = 4096,
        embed_dim: int = 1024,
        nhead: int = 16,
        ff_dim: int = 4096,
        num_layers: int = 2,
        dropout: float = 0.1,
        residual_clip: float = 1.0,
        use_critic: bool = True
    ):
        super().__init__()
        self.policy = EFNPolicyNetwork(
            vis_dim=vis_dim, token_dim=token_dim,
            embed_dim=embed_dim, nhead=nhead,
            ff_dim=ff_dim, num_layers=num_layers,
            dropout=dropout, residual_clip=residual_clip
        )
        self.critic = EFNCriticNetwork(
            vis_dim=vis_dim, token_dim=token_dim,
            embed_dim=embed_dim, ff_dim=max(2048, embed_dim * 2)
        ) if use_critic else None

    @torch.no_grad()
    def refine_latent(
        self,
        latent_tokens_cur: torch.Tensor,
        visual_embed_cur: torch.Tensor,
        latent_tokens_exp: torch.Tensor,
        visual_embed_exp: torch.Tensor,
    ) -> torch.Tensor:
        residual = self.policy(latent_tokens_cur, visual_embed_cur, latent_tokens_exp, visual_embed_exp)
        return latent_tokens_cur + residual

    def compute_residual(
        self,
        latent_tokens_cur: torch.Tensor,
        visual_embed_cur: torch.Tensor,
        latent_tokens_exp: torch.Tensor,
        visual_embed_exp: torch.Tensor,
    ) -> torch.Tensor:
        return self.policy(latent_tokens_cur, visual_embed_cur, latent_tokens_exp, visual_embed_exp)

    def forward(
        self,
        latent_tokens_cur: torch.Tensor,   # (B, 4, 4096)
        visual_embed_cur: torch.Tensor,    # (B, 256, 4096)
        latent_tokens_exp: torch.Tensor,   # (B, 4, 4096)
        visual_embed_exp: torch.Tensor,    # (B, 256, 4096)
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
        residual = self.policy(latent_tokens_cur, visual_embed_cur, latent_tokens_exp, visual_embed_exp)
        value = (self.critic(latent_tokens_cur, visual_embed_cur, latent_tokens_exp, visual_embed_exp)
                 if self.critic is not None else None)
        return residual, value


def benchmark_step(name: str, model: EFNModel,
                   latent_cur: torch.Tensor,
                   visual_cur: torch.Tensor,
                   latent_exp: torch.Tensor,
                   visual_exp: torch.Tensor,
                   warmup: int = 50,
                   iters: int = 200) -> float:
    """
    只测 EFN 自身的 step 级前向开销（ms/step）。
    """
    model.eval()
    torch.set_grad_enabled(False)

    # warmup
    for _ in range(warmup):
        _ = model(latent_cur, visual_cur, latent_exp, visual_exp)
    if torch.cuda.is_available():
        torch.cuda.synchronize()

    start = time.perf_counter()
    for _ in range(iters):
        _ = model(latent_cur, visual_cur, latent_exp, visual_exp)
    if torch.cuda.is_available():
        torch.cuda.synchronize()
    elapsed = time.perf_counter() - start

    per_step_ms = elapsed / iters * 1000.0
    print(f"[{name}] {per_step_ms:.3f} ms / step (iters={iters})")
    return per_step_ms


if __name__ == "__main__":
    device = "cuda" if torch.cuda.is_available() else "cpu"
    dtype = torch.float16 if device == "cuda" else torch.float32

    B = 2
    # 固定 dummy 输入，所有方案共用
    latent_cur = torch.randn(B, 4, 4096, device=device, dtype=dtype)
    visual_cur = torch.randn(B, 256, 4096, device=device, dtype=dtype)
    latent_exp = torch.randn(B, 4, 4096, device=device, dtype=dtype)
    visual_exp = torch.randn(B, 256, 4096, device=device, dtype=dtype)

    # 不同 EFN 设计方案（你可以按需增删）
    configs = [
        # 论文中实际使用的配置
        ("EFN(policy+critic, 2-layer enc)",
         dict(use_critic=True,  embed_dim=1024, num_layers=2)),
        # 部署时只用 policy 分支
        ("EFN(policy only, 2-layer enc)",
         dict(use_critic=False, embed_dim=1024, num_layers=2)),
        # 更小的 transformer（对比“更轻的 EFN”）
        ("EFN(policy only, 1-layer enc)",
         dict(use_critic=False, embed_dim=1024, num_layers=1)),
        # 更宽的 embedding（对比“更重的 EFN”）
        ("EFN(policy only, 2-layer enc, 1536-d)",
         dict(use_critic=False, embed_dim=1536, num_layers=2)),
    ]

    results = {}
    for name, cfg in configs:
        model = EFNModel(
            vis_dim=4096,
            token_dim=4096,
            ff_dim=4096,
            dropout=0.1,
            **cfg
        ).to(device)
        ms = benchmark_step(name, model,
                            latent_cur, visual_cur,
                            latent_exp, visual_exp)
        results[name] = ms

    # 以第一个配置作为基准，打印相对开销，方便直接写进论文
    print("\nRelative overhead (vs. first config):")
    base_name = list(results.keys())[0]
    base_ms = results[base_name]
    for name, ms in results.items():
        rel = (ms / base_ms - 1.0) * 100.0
        print(f"{name}: {ms:.3f} ms, Δ = {rel:+.2f}%")