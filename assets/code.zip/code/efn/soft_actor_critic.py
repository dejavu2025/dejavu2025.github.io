import math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from prismatic.models.policy.transformer_utils import MAPBlock

# Actor/Critic (GC-SAC, 4-stream)
class EFNStochasticActor(nn.Module):
    def __init__(self, embed_dim=1024, nhead=16, ff_dim=4096, num_layers=2, dropout=0.1,
                 min_logstd=-20.0, max_logstd=2.0):
        super().__init__()
        self.min_logstd, self.max_logstd = min_logstd, max_logstd
        self.visual_pool_cur = MAPBlock(n_latents=4, vis_dim=4096, embed_dim=embed_dim, n_heads=max(1, embed_dim // 64))
        self.visual_pool_exp = MAPBlock(n_latents=4, vis_dim=4096, embed_dim=embed_dim, n_heads=max(1, embed_dim // 64))
        self.token_in_cur = nn.Linear(4096, embed_dim)
        self.token_in_exp = nn.Linear(4096, embed_dim)
        self.q_ln = nn.LayerNorm(embed_dim)
        self.k_ln = nn.LayerNorm(embed_dim)
        self.v_ln = nn.LayerNorm(embed_dim)
        self.cross = nn.MultiheadAttention(embed_dim, nhead, dropout=dropout, batch_first=True)
        self.cross_ff = nn.Sequential(
            nn.LayerNorm(embed_dim),
            nn.Linear(embed_dim, ff_dim), nn.GELU(), nn.Dropout(dropout),
            nn.Linear(ff_dim, embed_dim),
        )
        enc = nn.TransformerEncoderLayer(d_model=embed_dim, nhead=nhead,
                                         dim_feedforward=ff_dim, dropout=dropout,
                                         batch_first=True, norm_first=True, activation="gelu")
        self.encoder = nn.TransformerEncoder(enc, num_layers=num_layers)
        self.out_ln = nn.LayerNorm(embed_dim)
        self.mean = nn.Sequential(nn.Linear(embed_dim, ff_dim), nn.GELU(), nn.Linear(ff_dim, 4096))
        self.logstd = nn.Sequential(nn.Linear(embed_dim, ff_dim), nn.GELU(), nn.Linear(ff_dim, 4096))

    def forward(self, latent_cur, visual_cur, latent_exp, visual_exp):
        v_cur4 = self.visual_pool_cur(visual_cur)     # (B,4,E)
        v_exp4 = self.visual_pool_exp(visual_exp)     # (B,4,E)
        q_cur = self.token_in_cur(latent_cur)         # (B,4,E)
        k_exp = self.token_in_exp(latent_exp)         # (B,4,E)
        kv = torch.cat([v_cur4, v_exp4, k_exp], dim=1)
        x, _ = self.cross(self.q_ln(q_cur), self.k_ln(kv), self.v_ln(kv))
        x = x + self.cross_ff(x)
        x = self.encoder(x)
        x = self.out_ln(x)
        mu = torch.tanh(self.mean(x))                 # (B,4,4096)
        logstd = self.logstd(x).clamp(self.min_logstd, self.max_logstd)
        std = torch.exp(logstd)
        eps = torch.randn_like(mu)
        a = mu + eps * std
        r = torch.tanh(a)                             # residual in [-1,1]
        logp_gauss = (-0.5 * ((a - mu) / (std + 1e-6))**2 - logstd - 0.5*math.log(2*math.pi)).sum(dim=[1,2], keepdim=True)
        logp = logp_gauss - torch.sum(torch.log(1 - r**2 + 1e-6), dim=[1,2], keepdim=True)  # [B,1,1]
        return r, logp, mu

class TwinQ(nn.Module):
    def __init__(self, embed_dim=512, hidden=1024):
        super().__init__()
        self.vpool = MAPBlock(n_latents=4, vis_dim=4096, embed_dim=embed_dim, n_heads=8)
        self.proj_lat = nn.Linear(4096, embed_dim)
        self.proj_exp = nn.Linear(4096, embed_dim)
        self.proj_act = nn.Linear(4096, embed_dim)
        in_dim = 4 * (embed_dim * 4)
        def mlp():
            return nn.Sequential(
                nn.Linear(in_dim, hidden), nn.GELU(),
                nn.Linear(hidden, hidden), nn.GELU(),
                nn.Linear(hidden, 1),
            )
        self.q1 = mlp(); self.q2 = mlp()

    def forward(self, latent_cur, visual_cur, latent_exp, residual):
        B = latent_cur.size(0)
        v4 = self.vpool(visual_cur)
        lc = self.proj_lat(latent_cur)
        le = self.proj_exp(latent_exp)
        ra = self.proj_act(residual)
        x = torch.cat([v4, lc, le, ra], dim=-1).reshape(B, -1)
        return self.q1(x), self.q2(x)

# Replay Buffer (CPU storage)
class Replay:
    def __init__(self, cap=200000):
        self.cap = cap; self.buf = []; self.idx = 0
    def add(self, **kw):
        if len(self.buf) < self.cap: self.buf.append(kw)
        else: self.buf[self.idx] = kw
        self.idx = (self.idx + 1) % self.cap
    def sample(self, B):
        idxs = np.random.randint(0, len(self.buf), size=B)
        out = {k: [] for k in self.buf[0].keys()}
        for i in idxs:
            for k,v in self.buf[i].items(): out[k].append(v)
        for k, x in out.items():
            if isinstance(x[0], (float,int)):
                out[k] = torch.tensor(x, dtype=torch.float32)  # [B]
            else:
                out[k] = torch.stack(x, 0).float()             # CPU tensors stacked
        return out
    def __len__(self): return len(self.buf)

# Reward shaping and experience selection
class RewardShaper:
    """
    Simple affine transformation of raw rewards.

    In many cases the raw Sinkhorn similarity has a high mean and small
    variance, making it hard for SAC to learn.  RewardShaper subtracts a
    constant baseline and multiplies by a scale factor so that the shaped
    reward has a more suitable distribution.  If you set baseline=0 and
    scale=1 the raw reward is passed through unchanged.
    """
    def __init__(self, baseline: float = 0.0, scale: float = 1.0):
        self.baseline = float(baseline)
        self.scale = float(scale)

    def shape(self, raw: float) -> float:
        return (raw - self.baseline) * self.scale