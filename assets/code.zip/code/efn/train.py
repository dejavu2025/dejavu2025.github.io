# -*- coding: utf-8 -*-
"""
Train EFN with Goal-Conditioned SAC using local experience bank.

Key idea:
- At each env step, retrieve the most similar experience E_{m,n} from bank.jsonl.
- Feed (cur_latent/visual, exp_latent/visual) to a 4-stream stochastic actor (EFN-style).
- Execute action: a_t = decode(latent_cur + residual).
- Reward: progress toward E_{m,n+1}'s pooled visual token g (dense cosine-improvement).

This script is designed to fit the 4 existing scripts:
  - efn_model.py (reference architecture and shapes)
  - efn_recorder.py (bank.jsonl format and .npz keys)
  - efn_sim_retriever.py (read_bank_jsonl/topk retrieval)
  - save_experience.py (ActionDecoder for consistency with inference)

Author: EFN
"""
from __future__ import annotations
import os, json, math, argparse, random, time
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple, Optional, Union
import numpy as np
import torch
from tqdm import tqdm
from PIL import Image
import torch.nn as nn
import torch.nn.functional as F
from pathlib import Path
# ---- Project imports (existing code) ----
import sys
sys.path.append("../")
sys.path.append("../..")
sys.path.append("../../..")
sys.path.append("./")
from efn.efn_sim_retriever import read_bank_jsonl, load_npz_features  # bank jsonl IO helpers :contentReference[oaicite:6]{index=6}
from efn.efn_sim_retriever import Config as SimCfg  # just to reuse pool hyper if needed
from efn.efn_recorder import _pool_visual_embed_meanmax  # simple mean-max pool to 4096 :contentReference[oaicite:9]{index=9}
from save_experience import ActionDecoder  # keep same decoding behavior as data collection :contentReference[oaicite:7]{index=7}
from experiments.robot.libero.libero_utils import get_libero_env, get_libero_image, save_rollout_video
from experiments.robot.openvla_utils import get_processor
from experiments.robot.robot_utils import (
    get_latent_action, normalize_gripper_action, invert_gripper_action
)
from prismatic.extern.hf.modeling_prismatic import OpenVLAForActionPrediction
from prismatic.extern.hf.processing_prismatic import PrismaticProcessor
from prismatic.models.policy.transformer_utils import MAPBlock
from experiments.robot.robot_utils import (
    DATE_TIME,
    get_latent_action,
    get_image_resize_size,
    get_model,
    invert_gripper_action,
    normalize_gripper_action,
    set_seed_everywhere,
)
# Utils

def set_seed(seed: int):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)

def token_cosine_matrix(X, Y):
    # X,Y: [256,4096]
    Xn = F.normalize(X, dim=-1)
    Yn = F.normalize(Y, dim=-1)
    return Xn @ Yn.T  # [256,256],  cos 

def sinkhorn_similarity(X, Y, eps=0.05, n_iters=50):
    S = token_cosine_matrix(X, Y)                        # [256,256]
    # 2) Kernel eps 
    K = torch.exp(S / eps)                               # [256,256]
    # 3) Sinkhorn  = 1/256
    r = torch.full((K.size(0),), 1.0 / K.size(0), device=K.device)
    c = torch.full((K.size(1),), 1.0 / K.size(1), device=K.device)
    u = torch.ones_like(r); v = torch.ones_like(c)
    for _ in range(n_iters):
        u = r / (K @ v + 1e-8)
        v = c / (K.T @ u + 1e-8)
    P = torch.diag(u) @ K @ torch.diag(v)               # [256,256]
    score = (P * S).sum()                                # 
    #  S∈[-1,1]P =1 [0,1]
    score01 = 0.5 * (torch.clamp(score, -1.0, 1.0) + 1.0)
    return score01, P, S

# Experience Bank (reader + neighbor)

class ExperienceBank:
    """
    Load bank.jsonl and allow E_{m,n} lookup as well as E_{m,n+1} target.
    Each JSONL line: {rollout_id, step_idx, image, features, ...}
    The .npz has keys: visual_embed (pooled 4096), latent_action (4x4096), generated_ids. :contentReference[oaicite:8]{index=8}
    """
    def __init__(self, bank_jsonl: str, device: Optional[Union[str, torch.device]] = None):
        self.root = os.path.dirname(bank_jsonl)
        self.key_root = os.path.join('/root/work/UniVLA/experiences', self.root.split('experiences/')[-1])
        self.visual_key, self.raws = self.read_bank_simplify(bank_jsonl)  # simpler reader if you only need visual+features
        self.visual_key = torch.from_numpy(np.stack(self.visual_key, 0)).float().to(device)  # (N,4096)
        self.sample_tau = 0.05
        # Index (rollout_id, step_idx) -> features path
        self.by_key: Dict[Tuple[str,int], Dict] = {}
        for r in self.raws:
            self.by_key[(r["rollout_id"], int(r["step_idx"]))] = r
        # Build list of feature paths resolved to abs
        
    def read_bank_simplify(self, path: str):
        visual_key, raws = [], []
        with open(path, "r", encoding="utf-8") as fh:
            for line in tqdm(fh, desc="Reading bank"):
                if not line.strip():
                    continue
                obj = json.loads(line)
                raws.append(obj)
                key_path = os.path.join(self.key_root, obj.get("key"))
                key = np.load(key_path, allow_pickle=True)
                visual_key.append(key)
        return visual_key, raws

    def _abs_path(self, rel_or_abs: str) -> str:
        return rel_or_abs if os.path.isabs(rel_or_abs) else os.path.join(self.root, rel_or_abs)

    def load_step(self, rollout_id: str, step_idx: int) -> Optional[Dict[str, np.ndarray]]:
        meta = self.by_key.get((rollout_id, step_idx))
        if meta is None: return None
        feats = load_npz_features(self._abs_path(meta["features"]))  # visual_embed / latent_action / generated_ids :contentReference[oaicite:10]{index=10}
        feats["_meta"] = meta
        return feats

    def get_next_of(self, rollout_id: str, step_idx: int) -> Optional[Dict[str, np.ndarray]]:
        return self.load_step(rollout_id, step_idx + 1)

    # Simple top-1 NN using pooled visual cosine vs. query pooled visual
    # (fast baseline; if you want full CLIP rerank, wire efn_sim_retriever.EFNSim here)
    def top1_by_visual(self, query: np.ndarray) -> Tuple[Dict, Dict]:
        sims = F.cosine_similarity(query.unsqueeze(0), self.visual_key)  
        idx = sims.argmax().item()
        bank_volume = len(self.raws)
        if idx + 1 >= bank_volume:
            return idx-1, idx
        if self.raws[idx]["rollout_id"] != self.raws[idx + 1]["rollout_id"]:
            return idx-1, idx
        return idx, idx + 1
    
    def select_by_probability(self, query: np.ndarray) -> Tuple[Dict, Dict]:
        sims = F.cosine_similarity(query.unsqueeze(0), self.visual_key)  
        sims_t = torch.tensor(sims, dtype=torch.float32)
        logits = (sims_t - sims_t.max()) / max(self.sample_tau, 1e-6)
        probs = torch.softmax(logits, dim=0)
        idx = torch.multinomial(probs, num_samples=1).item()
        bank_volume = len(self.raws)
        if idx + 1 >= bank_volume:
            return idx-1, idx
        if self.raws[idx]["rollout_id"] != self.raws[idx + 1]["rollout_id"]:
            return idx-1, idx
        return idx, idx + 1
    
    def get_image_by_index(self, index: int) -> Dict:
        raw = self.raws[index]
        image_path = raw.get("image")
        return Image.open(image_path).convert("RGB")
    
    def reload_experience_by_index(self, idx: int):
        raw = self.raws[idx]
        feature_path = os.path.join(self.root, raw.get("feature"))
        feature = np.load(feature_path, allow_pickle=True)
        return feature


# Actor/Critic (GC-SAC, 4-stream, EFN-style)

class EFNStochasticActor(nn.Module):
    """
    4-stream stochastic actor, mirroring EFNPolicyNetwork (cross-attn + tiny encoder) but
    outputs tanh-Gaussian (mean/logstd) residual over 4x4096 latent tokens.
    Shapes match efn_model.py: latent_cur/exp: (B,4,4096), visual_cur/exp: (B,256,4096). :contentReference[oaicite:11]{index=11}
    """
    def __init__(self, embed_dim=1024, nhead=16, ff_dim=4096, num_layers=2, dropout=0.1,
                 min_logstd=-20.0, max_logstd=2.0):
        super().__init__()
        self.min_logstd, self.max_logstd = min_logstd, max_logstd
        # visual pools
        self.visual_pool_cur = MAPBlock(n_latents=4, vis_dim=4096, embed_dim=embed_dim, n_heads=max(1, embed_dim // 64))
        self.visual_pool_exp = MAPBlock(n_latents=4, vis_dim=4096, embed_dim=embed_dim, n_heads=max(1, embed_dim // 64))
        # token in
        self.token_in_cur = nn.Linear(4096, embed_dim)
        self.token_in_exp = nn.Linear(4096, embed_dim)
        # cross-attn
        self.q_ln = nn.LayerNorm(embed_dim)
        self.k_ln = nn.LayerNorm(embed_dim)
        self.v_ln = nn.LayerNorm(embed_dim)
        self.cross = nn.MultiheadAttention(embed_dim, nhead, dropout=dropout, batch_first=True)
        self.cross_ff = nn.Sequential(
            nn.LayerNorm(embed_dim),
            nn.Linear(embed_dim, ff_dim), nn.GELU(), nn.Dropout(dropout),
            nn.Linear(ff_dim, embed_dim),
        )
        # tiny encoder over 4 tokens
        enc = nn.TransformerEncoderLayer(d_model=embed_dim, nhead=nhead,
                                         dim_feedforward=ff_dim, dropout=dropout,
                                         batch_first=True, norm_first=True, activation="gelu")
        self.encoder = nn.TransformerEncoder(enc, num_layers=num_layers)
        self.out_ln = nn.LayerNorm(embed_dim)
        # heads
        self.mean = nn.Sequential(nn.Linear(embed_dim, ff_dim), nn.GELU(), nn.Linear(ff_dim, 4096))
        self.logstd = nn.Sequential(nn.Linear(embed_dim, ff_dim), nn.GELU(), nn.Linear(ff_dim, 4096))

    def forward(self, latent_cur, visual_cur, latent_exp, visual_exp):
        # visual pools (B,4,E)
        v_cur4 = self.visual_pool_cur(visual_cur)
        v_exp4 = self.visual_pool_exp(visual_exp)
        # project tokens (B,4,E)
        q_cur = self.token_in_cur(latent_cur)
        k_exp = self.token_in_exp(latent_exp)
        # context 12 tokens
        kv = torch.cat([v_cur4, v_exp4, k_exp], dim=1)
        # cross
        x, _ = self.cross(self.q_ln(q_cur), self.k_ln(kv), self.v_ln(kv))
        x = x + self.cross_ff(x)
        x = self.encoder(x)
        x = self.out_ln(x)
        # per-token heads
        mu = torch.tanh(self.mean(x))             # (B,4,4096) in [-1,1]
        logstd = self.logstd(x).clamp(self.min_logstd, self.max_logstd)
        std = torch.exp(logstd)
        eps = torch.randn_like(mu)
        a = mu + eps * std           # unsquashed
        r = torch.tanh(a)            # residual in [-1,1]
        # log-prob with tanh correction
        logp_gauss = (-0.5 * ((a - mu) / (std + 1e-6))**2 - logstd - 0.5*math.log(2*math.pi)).sum(dim=[1,2], keepdim=True)
        logp = logp_gauss - torch.sum(torch.log(1 - r**2 + 1e-6), dim=[1,2], keepdim=True)
        return r, logp, mu

class TwinQ(nn.Module):
    """Critics take (cur_latent, cur_visual, exp_latent, exp_visual, residual) and output Q."""
    def __init__(self, embed_dim=512, hidden=1024):
        super().__init__()
        self.vpool_cur = MAPBlock(n_latents=4, vis_dim=4096, embed_dim=embed_dim, n_heads=8)
        self.vpool_exp = MAPBlock(n_latents=4, vis_dim=4096, embed_dim=embed_dim, n_heads=8)
        # / latent + 
        self.proj_lat_cur = nn.Linear(4096, embed_dim)
        self.proj_lat_exp = nn.Linear(4096, embed_dim)
        self.proj_act     = nn.Linear(4096, embed_dim)  # residual token

        # token 5 [v_cur4, v_exp4, lc, le, ra] E 
        #  4  token = 4 * (5*E) = 20E
        in_dim = 4 * (embed_dim * 5)

        def mlp():
            return nn.Sequential(
                nn.Linear(in_dim, hidden), nn.GELU(),
                nn.Linear(hidden, hidden), nn.GELU(),
                nn.Linear(hidden, 1),
            )

        self.q1 = mlp()
        self.q2 = mlp()

    def _f(self, latent_cur, visual_cur, latent_exp, visual_exp, residual):
        """
        latent_*: (B,4,4096)
        visual_*: (B,256,4096)
        residual : (B,4,4096)
        """
        B = latent_cur.shape[0]
        #  -> (B,4,E)
        v_cur4 = self.vpool_cur(visual_cur)
        v_exp4 = self.vpool_exp(visual_exp)
        #  -> (B,4,E)
        lc = self.proj_lat_cur(latent_cur)
        le = self.proj_lat_exp(latent_exp)
        ra = self.proj_act(residual)
        # per-token  -> (B,4,5E) token  -> (B, 20E)
        x = torch.cat([v_cur4, v_exp4, lc, le, ra], dim=-1)
        x = x.reshape(B, -1)
        return x

    def forward(self, latent_cur, visual_cur, latent_exp, visual_exp, residual):
        x = self._f(latent_cur, visual_cur, latent_exp, visual_exp, residual)
        return self.q1(x), self.q2(x)


# Replay Buffer

class Replay:
    def __init__(self, cap=200000):
        self.cap = cap; self.buf = []; self.idx = 0
    def add(self, **kw):
        if len(self.buf) < self.cap: self.buf.append(kw)
        else: self.buf[self.idx] = kw
        self.idx = (self.idx + 1) % self.cap
    def sample(self, B):
        idxs = np.random.randint(0, len(self.buf), size=B)
        out = {k: [] for k in self.buf[0].keys()}
        for i in idxs:
            for k,v in self.buf[i].items(): out[k].append(v)
        for k in out:
            x = out[k]
            if isinstance(x[0], (float,int)): out[k] = torch.tensor(x, dtype=torch.float32).unsqueeze(-1)
            else: out[k] = torch.stack(x, 0).float()
        return out
    def __len__(self): return len(self.buf)





def train(cfg):
    set_seed(cfg.seed)
    device = torch.device(cfg.device)
    model = get_model(cfg)
    if cfg.model_family == "openvla":
    # In some cases, the key must be manually modified (e.g. after training on a modified version of the dataset
    # with the suffix "_no_noops" in the dataset name)
        if cfg.unnorm_key not in model.norm_stats and f"{cfg.unnorm_key}_no_noops" in model.norm_stats:
            cfg.unnorm_key = f"{cfg.unnorm_key}_no_noops"
        assert cfg.unnorm_key in model.norm_stats, f"Action un-norm key {cfg.unnorm_key} not found in VLA `norm_stats`!"
    # Load VLA + processor
    processor: PrismaticProcessor = get_processor(cfg)

    # Load ActionDecoder (same as data collection)
    decoder = ActionDecoder(window_size=cfg.window_size).eval().to(device)
    decoder.net.load_state_dict(torch.load(cfg.action_decoder_path, map_location=device))
    # Bank
    bank = ExperienceBank(cfg.bank_jsonl, cfg.device)

    # Init env
    from libero.libero import benchmark
    suite = benchmark.get_benchmark_dict()[cfg.task_suite_name]()
    latent_action_detokenize = [f'<ACT_{i}>' for i in range(32)]


    # Actor/critic/targets
    actor = EFNStochasticActor().to(device)
    critic = TwinQ().to(device)
    critic_tgt = TwinQ().to(device); critic_tgt.load_state_dict(critic.state_dict())

    opt_actor = torch.optim.Adam(actor.parameters(), lr=cfg.lr_actor)
    opt_critic = torch.optim.Adam(critic.parameters(), lr=cfg.lr_critic)
    log_alpha = torch.tensor(0.0, requires_grad=True, device=device)
    opt_alpha = torch.optim.Adam([log_alpha], lr=cfg.lr_alpha)

    alpha = lambda: log_alpha.exp()

    # Replay
    D = Replay(cap=200000)
    total_successes = 0
    global_step = 0
    for epoch in range(cfg.epochs):
        replay_images = []
        # select_task = random.randint(0, suite.n_tasks - 1)
        select_task = 0
        task = suite.get_task(select_task)
        env, task_description = get_libero_env(task, "openvla", resolution=cfg.resize)
        cnt_step = 0
        # Reset env
        obs = env.reset()
        # Wait few steps as in data collection
        for _ in range(cfg.num_steps_wait):
            obs, _, _, _ = env.step([0,0,0,0,0,0,-1])

        done = False
        hist_action = ''
        prev_hist_action = ['']
        latent_next, visual_next, generated_ids_next = None, None, None
        while not done and cnt_step < cfg.steps_per_epoch + cfg.num_steps_wait:
            # --- Build current observation (VLA features)
            if latent_next is not None:
                latent_cur, visual_cur, generated_ids = latent_next, visual_next, generated_ids_next
            else:
                img = get_libero_image(obs, cfg.resize)
                replay_images.append(img)
                observation = {"full_image": img,
                            "state": np.concatenate((obs["robot0_eef_pos"], obs["robot0_eef_quat"], obs["robot0_gripper_qpos"]))}

                with torch.no_grad():
                                    # Prepare history latent action tokens
                    start_idx = len(prev_hist_action) if len(prev_hist_action) < 4 else 4
                    prompt_hist_action_list = [prev_hist_action[idx] for idx in range(-1 * start_idx, 0)]
                    prompt_hist_action = ''
                    for latent_action in prompt_hist_action_list:
                        prompt_hist_action += latent_action
                    
                    # Query model to get action
                    latent_cur, visual_cur, generated_ids = get_latent_action(cfg,model,observation,task_description,processor=processor,hist_action=prev_hist_action[-1])
                    hist_action = ''
                    for latent_action_ids in generated_ids[0]:
                        hist_action += latent_action_detokenize[latent_action_ids.item() - 32001]
                    prev_hist_action.append(hist_action)
            # latent_cur: (1,4,4096), visual_cur: (1,256,4096)

            # --- Retrieve best E_{m,n} from bank using pooled visual (fast cosine)
            z_cur = _pool_visual_embed_meanmax(visual_cur)  # (1,4096)
            idx_n, idx_n1 = bank.select_by_probability(z_cur)  # exp_n has keys incl. 'latent_action','visual_embed'
            feature_n, feature_n1 = bank.reload_experience_by_index(idx_n), bank.reload_experience_by_index(idx_n1)
            visual_embed_n, latent_action_n = feature_n["visual_embed"], feature_n["latent_action"]
            visual_embed_n1, latent_action_n1 = feature_n1["visual_embed"], feature_n1["latent_action"]
            visual_embed_n = torch.from_numpy(visual_embed_n).float().unsqueeze(0).to(device)
            latent_action_n = torch.from_numpy(latent_action_n).float().unsqueeze(0).to(device)
            visual_embed_n1 = torch.from_numpy(visual_embed_n1).float().unsqueeze(0).to(device)
            latent_action_n1 = torch.from_numpy(latent_action_n1).float().unsqueeze(0).to(device)
            # --- Actor sample residual
            r, logp, _ = actor(latent_cur.float(), visual_cur.float(), latent_action_n, visual_embed_n)  # (1,4,4096)
            refined = (latent_cur + r).to(torch.float32)
            # --- Decode to env action (7-D), same path as save_experience.py
            # Get action norm stats from model
            stats = model.get_action_stats(cfg.unnorm_key)  # adjust if needed
            mask = stats.get("mask", np.ones_like(stats["q01"], dtype=bool))
            action_high, action_low = np.array(stats["q99"]), np.array(stats["q01"])
            a7 = decoder(refined, visual_cur, mask, action_low, action_high)  # numpy
            a7 = normalize_gripper_action(a7, binarize=True)
            a7 = invert_gripper_action(a7)

            # --- Step env
            obs_next, _, done, info = env.step(a7.tolist())
            # --- Reward: progress toward goal
            img_next = get_libero_image(obs_next, cfg.resize)
            replay_images.append(img_next)
            observation_next = {"full_image": img_next,
                                "state": np.concatenate((obs_next["robot0_eef_pos"], obs_next["robot0_eef_quat"], obs_next["robot0_gripper_qpos"]))}
            with torch.no_grad():
                start_idx = len(prev_hist_action) if len(prev_hist_action) < 4 else 4
                prompt_hist_action_list = [prev_hist_action[idx] for idx in range(-1 * start_idx, 0)]
                prompt_hist_action = ''
                for latent_action in prompt_hist_action_list:
                    prompt_hist_action += latent_action

                latent_next, visual_next, generated_ids_next = get_latent_action(cfg,model,observation_next,task_description,processor=processor,hist_action=prev_hist_action[-1])
                # pool current and next
                hist_action = ''
                for latent_action_ids in generated_ids_next[0]:
                    hist_action += latent_action_detokenize[latent_action_ids.item() - 32001]
                prev_hist_action.append(hist_action)
                s_next_tgt, _, _ = sinkhorn_similarity(visual_next[0].float(), visual_embed_n1[0])  #  vs 
                s_cur_tgt,  _, _ = sinkhorn_similarity(visual_cur[0].float(),  visual_embed_n[0])   #  vs 
                s_cur_next, _, _ = sinkhorn_similarity(visual_next[0].float(), visual_cur[0].float())  # =

                # --- Progress
                progress = s_next_tgt - s_cur_tgt  # 

                # --- Hyperparams cfg  config
                w_abs      = getattr(cfg, "w_abs", 0.1)        # 
                w_prog     = getattr(cfg, "w_prog", 20)       # 
                w_motion   = getattr(cfg, "w_motion", 0.3)     # 
                w_lazy     = getattr(cfg, "w_lazy", 20)       # 
                eps_prog   = getattr(cfg, "eps_prog", 0.005)   # “”
                time_cost  = getattr(cfg, "time_penalty", 0.01)

                # --- Core terms
                R_abs    = s_next_tgt                              # 
                R_prog   = torch.clamp(progress, min=0.0)          # 
                R_motion = 1.0 - s_cur_next                        # 

                no_prog  = torch.clamp(eps_prog - progress, min=0.0)   # <=>0
                pen_lazy = s_next_tgt * no_prog * s_cur_next           #  ×  × 

                # --- Final reward
                reward_abs = w_abs * R_abs
                reward_progress = w_prog * R_prog
                reward_motion = w_motion * R_motion
                lazy_penalty = w_lazy * pen_lazy
                R = reward_abs + reward_progress + reward_motion - lazy_penalty - time_cost
                R = torch.clamp(R, -1.0, 1.0)  # 

                # --- Store transition
                D.add(
                    # s
                    latent_cur=latent_cur.detach().squeeze(0).cpu().to(torch.float16),    # [4,4096]
                    visual_cur=visual_cur.detach().squeeze(0).cpu().to(torch.float16),    # [256,4096]
                    latent_exp=latent_action_n.detach().squeeze(0).cpu().to(torch.float16),
                    visual_exp=visual_embed_n.detach().squeeze(0).cpu().to(torch.float16),

                    # a
                    residual=r.detach().squeeze(0).cpu().to(torch.float16),               # [4,4096]

                    reward=float(R.item()),
                    done=bool(done),

                    # s'+ E_{m,n+1}
                    latent_next=latent_next.detach().squeeze(0).cpu().to(torch.float16),  # [4,4096]
                    visual_next=visual_next.detach().squeeze(0).cpu().to(torch.float16),  # [256,4096]
                    latent_exp_next=latent_action_n1.detach().squeeze(0).cpu().to(torch.float16),
                    visual_exp_next=visual_embed_n1.detach().squeeze(0).cpu().to(torch.float16),
                )

            # --- Update
            print(f"Epoch {epoch} Total Step {global_step}: R={R:.4f}, reward_abs={reward_abs:.4f}, reward_progress={reward_progress:.4f}, reward_motion={reward_motion:.4f}, lazy_penalty={lazy_penalty:.4f}, Current Step {cnt_step}, idx_n={idx_n}, Task {task_description}")
            sys.stdout.flush()
            if len(D) >= cfg.batch_size:
                B = D.sample(cfg.batch_size)
                latent_cur_b   = B["latent_cur"].to(device).float()
                visual_cur_b   = B["visual_cur"].to(device).float()
                latent_exp_b   = B["latent_exp"].to(device).float()
                visual_exp_b   = B["visual_exp"].to(device).float()
                residual_b     = B["residual"].to(device).float()
                reward_b       = B["reward"].to(device).view(-1,1)
                done_b         = B["done"].to(device).float().view(-1,1)

                #  next 
                latent_next_b      = B["latent_next"].to(device).float()
                visual_next_b      = B["visual_next"].to(device).float()
                latent_exp_next_b  = B["latent_exp_next"].to(device).float()
                visual_exp_next_b  = B["visual_exp_next"].to(device).float()

                with torch.no_grad():
                    # π(s')  a'
                    r_next, logp_next, _ = actor(latent_next_b, visual_next_b, latent_exp_next_b, visual_exp_next_b)
                    logp_next = logp_next.view(logp_next.size(0), -1).sum(dim=1, keepdim=True)

                    #  target critic  Q(s', a')
                    q1_t, q2_t = critic_tgt(latent_next_b, visual_next_b, latent_exp_next_b, visual_exp_next_b, r_next)
                    q_tgt = torch.min(q1_t, q2_t) - alpha() * logp_next

                    # Bellman 
                    y = reward_b + (1.0 - done_b) * cfg.gamma * q_tgt

                # Critic Q(s, a)
                q1, q2 = critic(latent_cur_b, visual_cur_b, latent_exp_b, visual_exp_b, residual_b)
                loss_q = F.mse_loss(q1, y) + F.mse_loss(q2, y)

                opt_critic.zero_grad(set_to_none=True); loss_q.backward(); opt_critic.step()

                # -------- Actor loss --------
                r_samp, logp_samp, _ = actor(latent_cur_b, visual_cur_b, latent_exp_b, visual_exp_b)
                #  logp_samp  [B,1]
                logp_samp = logp_samp.view(logp_samp.size(0), -1).sum(dim=1, keepdim=True)      # [B,1]
                q1_pi, q2_pi = critic(latent_cur_b, visual_cur_b, latent_exp_b, visual_exp_b, r_samp)         # [B,1], [B,1]
                q_pi = torch.min(q1_pi, q2_pi)                                                  # [B,1]
                loss_pi = (alpha() * logp_samp - q_pi).mean()
                opt_actor.zero_grad(set_to_none=True); loss_pi.backward(); opt_actor.step()

                # -------- Temperature (alpha) --------
                #  target_entropy logp_samp  [B,1]
                loss_alpha = -(log_alpha * (logp_samp.detach() + cfg.target_entropy)).mean()
                opt_alpha.zero_grad(set_to_none=True); loss_alpha.backward(); opt_alpha.step()

                # -------- Soft target update --------
                with torch.no_grad():
                    for p, tp in zip(critic.parameters(), critic_tgt.parameters()):
                        tp.data.mul_(1.0 - cfg.tau).add_(cfg.tau * p.data)

            global_step += 1
            cnt_step += 1
            obs = obs_next
        if done:
            total_successes += 1
        if cfg.save_video:
            # Save a replay video of the episode
            save_rollout_video(
                replay_images, epoch, success=done, task_description=task_description
            )
        print(f"Success: {done}")
        print(f"# episodes completed so far: {epoch+1}")
        print(f"# successes: {total_successes} ({total_successes / (epoch+1) * 100:.1f}%)")
        print(f"# average step: {global_step / (epoch+1)}")
        print(f"[Epoch {epoch}] steps={cnt_step}, replay={len(D)}")

    print("Training finished.")

# CLI

@dataclass
class EFNConfig:
    # fmt: off
    # Model-specific parameters
    model_family: str = "openvla"
    pretrained_checkpoint: Union[str, Path] = r"/mnt/liqiuchang/univla-7b-224-sft-libero/univla-libero-goal"
    load_in_8bit: bool = False
    load_in_4bit: bool = False

    action_decoder_path: str = r"/mnt/liqiuchang/univla-7b-224-sft-libero/univla-libero-goal/action_decoder.pt"
    center_crop: bool = True
    save_video: bool = True

    # LIBERO environment-specific parameters
    task_suite_name: str = "libero_goal"      # libero_spatial / libero_object / libero_goal / libero_10 / libero_90
    action_unnorm_key: str = "libero_goal"
    unnorm_key: str = action_unnorm_key
    num_steps_wait: int = 10
    num_trials_per_task: int = 100
    window_size: int = 12

    # EFN / Experience bank
    bank_jsonl: str = "/mnt/liqiuchang/EFN/experiences/session_2025-09-14_05-46-36/bank.jsonl"  # ← 
    device: str = "cuda"

    # Training (SAC) hyper-params
    epochs: int = 100
    steps_per_epoch: int = 200
    batch_size: int = 32
    gamma: float = 0.98
    tau: float = 0.005
    lr_actor: float = 3e-4
    lr_critic: float = 3e-4
    lr_alpha: float = 3e-4
    #  4×4096  latent“” → 
    target_entropy: float = - (4 * 4096) * 0.25

    w_progress: float   = 1.0   # 
    w_motion:   float   = 1.0   # 
    time_penalty: float = 0.01  # 

    # Utils
    run_id_note: Optional[str] = None
    local_log_dir: str = "./experiments/eval_logs"
    use_wandb: bool = False
    wandb_project: str = "YOUR_WANDB_PROJECT"
    wandb_entity: str = "YOUR_WANDB_ENTITY"
    resize: int = 256
    seed: int = 7


def main():        
    train(EFNConfig())                

if __name__ == "__main__":
    main()