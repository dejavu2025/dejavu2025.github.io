# efn_recorder.py
# -*- coding: utf-8 -*-

import os
import io
import json
import time
import shutil
from dataclasses import dataclass, asdict
from typing import Any, Dict, Optional, Union, Sequence

import numpy as np

try:
    from PIL import Image
    _PIL_OK = True
except Exception:
    _PIL_OK = False

try:
    import torch
    _TORCH_OK = True
except Exception:
    _TORCH_OK = False


ArrayLike = Union[np.ndarray, "torch.Tensor"]  # type: ignore[name-defined]


def _to_numpy(x: Optional[ArrayLike]) -> Optional[np.ndarray]:
    if x is None:
        return None
    if _TORCH_OK and isinstance(x, torch.Tensor):
        x = x.detach().to("cpu").to(torch.float32).numpy()
    return np.asarray(x)

def _ensure_dir(p: str):
    os.makedirs(p, exist_ok=True)

def _save_png(array_hw3: np.ndarray, out_path: str):
    """
     uint8  float[0,1] HxWx3  3xHxW
    """
    if array_hw3 is None:
        raise ValueError("image array is None")
    arr = array_hw3
    if arr.ndim == 3 and arr.shape[0] in (1, 3) and arr.shape[0] != arr.shape[-1]:
        #  CxHxW -> HxWxC
        arr = np.transpose(arr, (1, 2, 0))
    if arr.dtype != np.uint8:
        arr = np.clip(arr, 0, 1) if np.issubdtype(arr.dtype, np.floating) else arr
        if np.issubdtype(arr.dtype, np.floating):
            arr = (arr * 255.0 + 0.5).astype(np.uint8)
        else:
            arr = arr.astype(np.uint8)
    if not _PIL_OK:
        #  PIL  PNG .npy
        np.save(out_path.replace(".png", ".npy"), arr)
        return
    im = Image.fromarray(arr[..., :3])
    im.save(out_path, format="PNG", compress_level=4)



def _pool_visual_embed_meanmax(visual: torch.Tensor) -> torch.Tensor:
    if visual.ndim == 3 and visual.shape[0] == 1:
        visual = visual[0]
    if visual.ndim != 2:
        raise ValueError(f"visual_embed expects [256,H] or [1,256,H], got {visual.shape}")
    eps = 1e-8
    visual = visual.float()  #  float32
    # L2  token
    visual = visual / (visual.norm(dim=-1, keepdim=True) + eps)  # [256, H]
    # mean pooling  max pooling
    mean = visual.mean(dim=0)   # [H]
    mx   = visual.max(dim=0).values  # [H]
    #  mean  max
    mean = mean / (mean.norm() + eps)
    mx   = mx / (mx.norm() + eps)
    u0 = 0.5 * mean + 0.5 * mx
    u0 = u0 / (u0.norm() + eps)  # [H]
    return u0


@dataclass
class StepEntry:
    #  bank.jsonl
    id: str
    rollout_id: str
    step_idx: int
    image: str             # png  bank.jsonl 
    key: str               # npy 
    feature: str           # npz 
    language: Optional[str] = None
    task_name: Optional[str] = None
    shapes: Optional[Dict[str, Sequence[int]]] = None


class ExperienceRecorder:
    """
    
        rec = ExperienceRecorder(out_root='experiences', session_name=None, overwrite=False)
        rec.start_session(meta={'exp':'libero-eval', 'policy':'UniVLA'})

        #  rollout 
        rec.start_rollout(rollout_id=f"rollout_{i:03d}", task_name=task_name, language=lang)

        #  step
        rec.record_step(
            obs=obs,
            env=env,   #  obs  env.render()
            step_idx=t,
            visual_embed=visual_embed,       # [256, H]
            latent_action=latent_action,     # [4, H]
            generated_ids=generated_ids,     # [4]
            rgb_image=None   #  HxWx3
        )

        # rollout 
        rec.end_rollout()

        rec.close()
    """

    def __init__(self, out_root: str = "experiences", session_name: Optional[str] = None, overwrite: bool = False):
        self.out_root = out_root
        _ensure_dir(self.out_root)

        if session_name is None:
            #  session_2025-09-12_01-23-45
            session_name = time.strftime("session_%Y-%m-%d_%H-%M-%S", time.localtime())
        self.session_name = session_name
        self.session_dir = os.path.join(self.out_root, self.session_name)
        if os.path.exists(self.session_dir):
            if overwrite:
                shutil.rmtree(self.session_dir)
            else:
                raise FileExistsError(f"Session directory already exists: {self.session_dir}")

        self.rollouts_dir = os.path.join(self.session_dir, "rollouts")
        _ensure_dir(self.rollouts_dir)

        self.bank_jsonl = os.path.join(self.session_dir, "bank.jsonl")
        self._bank_fh = open(self.bank_jsonl, "w", encoding="utf-8")

        self.meta_path = os.path.join(self.session_dir, "meta.json")
        self.session_meta: Dict[str, Any] = {}

        self._cur_rollout_id: Optional[str] = None
        self._cur_rollout_dir: Optional[str] = None
        self._cur_rollout_info: Dict[str, Any] = {}

    # ---------- Session ----------

    def start_session(self, meta: Optional[Dict[str, Any]] = None):
        self.session_meta = meta or {}
        with open(self.meta_path, "w", encoding="utf-8") as f:
            json.dump({
                "created_at": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
                "meta": self.session_meta
            }, f, ensure_ascii=False, indent=2)

    def close(self):
        if self._bank_fh:
            self._bank_fh.close()
            self._bank_fh = None

    # ---------- Rollout ----------

    def start_rollout(self, rollout_id: str, task_name: Optional[str] = None, language: Optional[str] = None):
        if self._cur_rollout_id is not None:
            raise RuntimeError("A rollout is already in progress. Call end_rollout() before starting a new one.")

        self._cur_rollout_id = rollout_id
        self._cur_rollout_dir = os.path.join(self.rollouts_dir, rollout_id)
        _ensure_dir(self._cur_rollout_dir)

        self._cur_rollout_info = {
            "task_name": task_name,
            "language": language,
            "start_time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
        }
        with open(os.path.join(self._cur_rollout_dir, "rollout_meta.json"), "w", encoding="utf-8") as f:
            json.dump(self._cur_rollout_info, f, ensure_ascii=False, indent=2)

    def end_rollout(self):
        if self._cur_rollout_id is None:
            return
        self._cur_rollout_info["end_time"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        with open(os.path.join(self._cur_rollout_dir, "rollout_meta.json"), "w", encoding="utf-8") as f:
            json.dump(self._cur_rollout_info, f, ensure_ascii=False, indent=2)
        self._cur_rollout_id = None
        self._cur_rollout_dir = None
        self._cur_rollout_info = {}

    # ---------- Step ----------

    def record_step(
        self,
        step_idx: int,
        visual_embed: Optional[ArrayLike],
        latent_action: Optional[ArrayLike],
        generated_ids: Optional[ArrayLike],
        rgb_image: Optional[ArrayLike] = None,
        state: Optional[ArrayLike]=None,
    ):
        """"""
        if self._cur_rollout_id is None:
            raise RuntimeError("No active rollout. Call start_rollout() first.")

        img_np = _to_numpy(rgb_image)
        step_stub = f"step_{step_idx:05d}"
        img_rel = os.path.join(self._cur_rollout_id, f"{step_stub}.png")
        _save_png(img_np, os.path.join(self._cur_rollout_dir, f"{step_stub}.png"))

        # 2)  numpy
        visual_np = _to_numpy(visual_embed).astype(np.float16)
        latent_np = _to_numpy(latent_action)
        ids_np = _to_numpy(generated_ids)
        shapes: Dict[str, Sequence[int]] = {}
        shapes["image"] = list(img_np.shape) if img_np is not None else None
        shapes["state"] = list(state.shape) if state is not None else None
        if visual_np is not None:
            # [256,H] →  [H]
            if visual_np.ndim == 3 and visual_np.shape[0] == 1:
                visual_np = visual_np[0]
            if visual_np.ndim != 2:
                raise ValueError(f"visual_embed expects [256,H], got {visual_np.shape}")
            shapes["visual_embed"] = list(visual_np.shape)
        #     visual_np = _pool_visual_embed_meanmax(visual_np)
        key = _pool_visual_embed_meanmax(visual_embed).cpu().numpy()
        shapes["visual_embed_meanmax"] = list(key.shape)

        if latent_np is not None:
            if latent_np.ndim == 3 and latent_np.shape[0] == 1:
                latent_np = latent_np[0]
            if latent_np.ndim != 2:
                raise ValueError(f"latent_action expects [4,H], got {latent_np.shape}")
            shapes["latent_action"] = list(latent_np.shape)

        if ids_np is not None:
            ids_np = ids_np.astype(np.int64).reshape(-1)
            shapes["generated_ids"] = list(ids_np.shape)

        #    .npy
        key_rel = os.path.join(self._cur_rollout_id, f"{step_stub}_key.npy")
        np.save(os.path.join(self._cur_rollout_dir, f"{step_stub}_key.npy"),
                key if key is not None else np.array([], dtype=np.float32))

        #    .npz
        feature_rel = os.path.join(self._cur_rollout_id, f"{step_stub}.npz")
        np.savez(os.path.join(self._cur_rollout_dir, f"{step_stub}.npz"),
                            state=state if state is not None else np.array([], dtype=np.float32),
                            visual_embed=visual_np if visual_np is not None else np.array([], dtype=np.float32),
                            latent_action=latent_np if latent_np is not None else np.array([], dtype=np.float32),
                            generated_ids=ids_np if ids_np is not None else np.array([], dtype=np.int64))

        # 4)  bank.jsonl
        entry = StepEntry(
            id=f"{self._cur_rollout_id}:{step_idx}",
            rollout_id=self._cur_rollout_id,
            step_idx=step_idx,
            image=os.path.join("rollouts", img_rel).replace("\\", "/"),
            key=os.path.join("rollouts", key_rel).replace("\\", "/"),
            feature=os.path.join("rollouts", feature_rel).replace("\\", "/"),
            language=self._cur_rollout_info.get("language"),
            task_name=self._cur_rollout_info.get("task_name"),
            shapes=shapes or None,
        )
        self._bank_fh.write(json.dumps(asdict(entry), ensure_ascii=False) + "\n")
        self._bank_fh.flush()