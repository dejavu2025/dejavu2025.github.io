# -*- coding: utf-8 -*-
"""
Train EFN with Goal-Conditioned SAC using local experience bank.

Key idea:
- At each env step, retrieve the most similar experience E_{m,n} from bank.jsonl.
- Feed (cur_latent/visual, exp_latent/visual) to a 4-stream stochastic actor (EFN-style).
- Execute action: a_t = decode(latent_cur + residual).
- Reward: progress toward E_{m,n+1}'s pooled visual token g (dense cosine-improvement).

This script is designed to fit the 4 existing scripts:
  - efn_model.py (reference architecture and shapes)
  - efn_recorder.py (bank.jsonl format and .npz keys)
  - efn_sim_retriever.py (read_bank_jsonl/topk retrieval)
  - save_experience.py (ActionDecoder for consistency with inference)

Author: EFN
"""
from __future__ import annotations
import os, json, math, argparse, random, time
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple, Optional, Union
import numpy as np
import torch
from tqdm import tqdm
from PIL import Image
import torch.nn as nn
import torch.nn.functional as F
from pathlib import Path
# ---- Project imports (existing code) ----
import sys
sys.path.append("../")
sys.path.append("../..")
sys.path.append("../../..")
sys.path.append("./")
from efn.efn_sim_retriever import read_bank_jsonl, load_npz_features  # bank jsonl IO helpers :contentReference[oaicite:6]{index=6}
from efn.efn_sim_retriever import Config as SimCfg  # just to reuse pool hyper if needed
from efn.efn_recorder import _pool_visual_embed_meanmax  # simple mean-max pool to 4096 :contentReference[oaicite:9]{index=9}
from save_experience import ActionDecoder  # keep same decoding behavior as data collection :contentReference[oaicite:7]{index=7}
from experiments.robot.libero.libero_utils import get_libero_env, get_libero_image, save_rollout_video
from experiments.robot.openvla_utils import get_processor
from experiments.robot.robot_utils import (
    get_latent_action, normalize_gripper_action, invert_gripper_action
)
from prismatic.extern.hf.modeling_prismatic import OpenVLAForActionPrediction
from prismatic.extern.hf.processing_prismatic import PrismaticProcessor
from prismatic.models.policy.transformer_utils import MAPBlock
from experiments.robot.robot_utils import (
    DATE_TIME,
    get_latent_action,
    get_image_resize_size,
    get_model,
    invert_gripper_action,
    normalize_gripper_action,
    set_seed_everywhere,
)
# -----------------------------
# Utils
# -----------------------------

def set_seed(seed: int):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)

def token_cosine_matrix(X, Y):
    # X,Y: [256,4096]
    Xn = F.normalize(X, dim=-1)
    Yn = F.normalize(Y, dim=-1)
    return Xn @ Yn.T

def sinkhorn_similarity(X, Y, eps=0.05, n_iters=50):
    S = token_cosine_matrix(X, Y)                        # [256,256]
    K = torch.exp(S / eps)                               # [256,256]
    r = torch.full((K.size(0),), 1.0 / K.size(0), device=K.device)
    c = torch.full((K.size(1),), 1.0 / K.size(1), device=K.device)
    u = torch.ones_like(r); v = torch.ones_like(c)
    for _ in range(n_iters):
        u = r / (K @ v + 1e-8)
        v = c / (K.T @ u + 1e-8)
    P = torch.diag(u) @ K @ torch.diag(v)               # [256,256]
    score = (P * S).sum()
    score01 = 0.5 * (torch.clamp(score, -1.0, 1.0) + 1.0)
    return score01, P, S

# -----------------------------
# Experience Bank (reader + neighbor)
# -----------------------------

class ExperienceBank:
    """
    Load bank.jsonl and allow E_{m,n} lookup as well as E_{m,n+1} target.
    Each JSONL line: {rollout_id, step_idx, image, features, ...}
    The .npz has keys: visual_embed (pooled 4096), latent_action (4x4096), generated_ids. :contentReference[oaicite:8]{index=8}
    """
    def __init__(self, bank_jsonl: str, device: Optional[Union[str, torch.device]] = None):
        self.root = os.path.dirname(bank_jsonl)
        self.key_root = os.path.join('/root/work/UniVLA/experiences', self.root.split('experiences/')[-1])
        self.visual_key, self.raws = self.read_bank_simplify(bank_jsonl)  # simpler reader if you only need visual+features
        self.visual_key = torch.from_numpy(np.stack(self.visual_key, 0)).float().to(device)  # (N,4096)
        self.sample_tau = 0.05
        # Index (rollout_id, step_idx) -> features path
        self.by_key: Dict[Tuple[str,int], Dict] = {}
        for r in self.raws:
            self.by_key[(r["rollout_id"], int(r["step_idx"]))] = r
        # Build list of feature paths resolved to abs
        
    def read_bank_simplify(self, path: str):
        visual_key, raws = [], []
        with open(path, "r", encoding="utf-8") as fh:
            for line in tqdm(fh, desc="Reading bank"):
                if not line.strip():
                    continue
                obj = json.loads(line)
                raws.append(obj)
                key_path = os.path.join(self.key_root, obj.get("key"))
                key = np.load(key_path, allow_pickle=True)
                visual_key.append(key)
        return visual_key, raws

    def _abs_path(self, rel_or_abs: str) -> str:
        return rel_or_abs if os.path.isabs(rel_or_abs) else os.path.join(self.root, rel_or_abs)

    def load_step(self, rollout_id: str, step_idx: int) -> Optional[Dict[str, np.ndarray]]:
        meta = self.by_key.get((rollout_id, step_idx))
        if meta is None: return None
        feats = load_npz_features(self._abs_path(meta["features"]))  # visual_embed / latent_action / generated_ids :contentReference[oaicite:10]{index=10}
        feats["_meta"] = meta
        return feats

    def get_next_of(self, rollout_id: str, step_idx: int) -> Optional[Dict[str, np.ndarray]]:
        return self.load_step(rollout_id, step_idx + 1)

    # Simple top-1 NN using pooled visual cosine vs. query pooled visual
    # (fast baseline; if you want full CLIP rerank, wire efn_sim_retriever.EFNSim here)
    def top1_by_visual(self, query: np.ndarray) -> Tuple[Dict, Dict]:
        sims = F.cosine_similarity(query.unsqueeze(0), self.visual_key)  
        idx = sims.argmax().item()
        bank_volume = len(self.raws)
        if idx + 1 >= bank_volume:
            return idx-1, idx
        if self.raws[idx]["rollout_id"] != self.raws[idx + 1]["rollout_id"]:
            return idx-1, idx
        return idx, idx + 1
    
    def select_by_probability(self, query: np.ndarray) -> Tuple[Dict, Dict]:
        sims = F.cosine_similarity(query.unsqueeze(0), self.visual_key)  
        sims_t = torch.tensor(sims, dtype=torch.float32)
        logits = (sims_t - sims_t.max()) / max(self.sample_tau, 1e-6)
        probs = torch.softmax(logits, dim=0)
        idx = torch.multinomial(probs, num_samples=1).item()
        bank_volume = len(self.raws)
        if idx + 1 >= bank_volume:
            return idx-1, idx
        if self.raws[idx]["rollout_id"] != self.raws[idx + 1]["rollout_id"]:
            return idx-1, idx
        return idx, idx + 1
    
    def get_image_by_index(self, index: int) -> Dict:
        raw = self.raws[index]
        image_path = raw.get("image")
        return Image.open(image_path).convert("RGB")
    
    def reload_experience_by_index(self, idx: int):
        raw = self.raws[idx]
        feature_path = os.path.join(self.root, raw.get("feature"))
        feature = np.load(feature_path, allow_pickle=True)
        return feature


# -----------------------------
# Actor/Critic (GC-SAC, 4-stream, EFN-style)
# -----------------------------

class EFNStochasticActor(nn.Module):
    """
    4-stream stochastic actor, mirroring EFNPolicyNetwork (cross-attn + tiny encoder) but
    outputs tanh-Gaussian (mean/logstd) residual over 4x4096 latent tokens.
    Shapes match efn_model.py: latent_cur/exp: (B,4,4096), visual_cur/exp: (B,256,4096). :contentReference[oaicite:11]{index=11}
    """
    def __init__(self, embed_dim=1024, nhead=16, ff_dim=4096, num_layers=2, dropout=0.1,
                 min_logstd=-20.0, max_logstd=2.0):
        super().__init__()
        self.min_logstd, self.max_logstd = min_logstd, max_logstd
        # visual pools
        self.visual_pool_cur = MAPBlock(n_latents=4, vis_dim=4096, embed_dim=embed_dim, n_heads=max(1, embed_dim // 64))
        self.visual_pool_exp = MAPBlock(n_latents=4, vis_dim=4096, embed_dim=embed_dim, n_heads=max(1, embed_dim // 64))
        # token in
        self.token_in_cur = nn.Linear(4096, embed_dim)
        self.token_in_exp = nn.Linear(4096, embed_dim)
        # cross-attn
        self.q_ln = nn.LayerNorm(embed_dim)
        self.k_ln = nn.LayerNorm(embed_dim)
        self.v_ln = nn.LayerNorm(embed_dim)
        self.cross = nn.MultiheadAttention(embed_dim, nhead, dropout=dropout, batch_first=True)
        self.cross_ff = nn.Sequential(
            nn.LayerNorm(embed_dim),
            nn.Linear(embed_dim, ff_dim), nn.GELU(), nn.Dropout(dropout),
            nn.Linear(ff_dim, embed_dim),
        )
        # tiny encoder over 4 tokens
        enc = nn.TransformerEncoderLayer(d_model=embed_dim, nhead=nhead,
                                         dim_feedforward=ff_dim, dropout=dropout,
                                         batch_first=True, norm_first=True, activation="gelu")
        self.encoder = nn.TransformerEncoder(enc, num_layers=num_layers)
        self.out_ln = nn.LayerNorm(embed_dim)
        # heads
        self.mean = nn.Sequential(nn.Linear(embed_dim, ff_dim), nn.GELU(), nn.Linear(ff_dim, 4096))
        self.logstd = nn.Sequential(nn.Linear(embed_dim, ff_dim), nn.GELU(), nn.Linear(ff_dim, 4096))

    def forward(self, latent_cur, visual_cur, latent_exp, visual_exp):
        # visual pools (B,4,E)
        v_cur4 = self.visual_pool_cur(visual_cur)
        v_exp4 = self.visual_pool_exp(visual_exp)
        # project tokens (B,4,E)
        q_cur = self.token_in_cur(latent_cur)
        k_exp = self.token_in_exp(latent_exp)
        # context 12 tokens
        kv = torch.cat([v_cur4, v_exp4, k_exp], dim=1)
        # cross
        x, _ = self.cross(self.q_ln(q_cur), self.k_ln(kv), self.v_ln(kv))
        x = x + self.cross_ff(x)
        x = self.encoder(x)
        x = self.out_ln(x)
        # per-token heads
        mu = torch.tanh(self.mean(x))             # (B,4,4096) in [-1,1]
        logstd = self.logstd(x).clamp(self.min_logstd, self.max_logstd)
        std = torch.exp(logstd)
        eps = torch.randn_like(mu)
        a = mu + eps * std           # unsquashed
        r = torch.tanh(a)            # residual in [-1,1]
        # log-prob with tanh correction
        logp_gauss = (-0.5 * ((a - mu) / (std + 1e-6))**2 - logstd - 0.5*math.log(2*math.pi)).sum(dim=[1,2], keepdim=True)
        logp = logp_gauss - torch.sum(torch.log(1 - r**2 + 1e-6), dim=[1,2], keepdim=True)
        return r, logp, mu

class TwinQ(nn.Module):
        latent_*: (B,4,4096)
        visual_*: (B,256,4096)
        residual : (B,4,4096)
