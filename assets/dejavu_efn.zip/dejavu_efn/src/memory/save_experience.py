import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Union
os.environ["TOKENIZERS_PARALLELISM"] = "false"
import torch
import torch.nn as nn
import torch.nn.functional as F
import draccus
import numpy as np
import tqdm
from libero.libero import benchmark
from collections import deque

import wandb
sys.path += ["../", "../..", "../../..", "./"]
from efn.efn_recorder import ExperienceRecorder



# Append current directory so that interpreter can find experiments.robot

from experiments.robot.libero.libero_utils import (
    get_libero_dummy_action,
    get_libero_env,
    get_libero_image,
    quat2axisangle,
    save_rollout_video,
)
from experiments.robot.openvla_utils import get_processor
from experiments.robot.robot_utils import (
    DATE_TIME,
    get_latent_action,
    get_image_resize_size,
    get_model,
    invert_gripper_action,
    normalize_gripper_action,
    set_seed_everywhere,
)



@dataclass
class GenerateConfig:
    # fmt: off

    #################################################################################################################
    # Model-specific parameters
    #################################################################################################################
    model_family: str = "openvla"                    # Model family
    model_name = "10"
    pretrained_checkpoint: Union[str, Path] = f"/mnt/liqiuchang/univla-7b-224-sft-libero/univla-libero-{model_name}"      # Pretrained checkpoint path
    load_in_8bit: bool = False                       # (For OpenVLA only) Load with 8-bit quantization
    load_in_4bit: bool = False                       # (For OpenVLA only) Load with 4-bit quantization
    
    action_decoder_path:str = f"/mnt/liqiuchang/univla-7b-224-sft-libero/univla-libero-{model_name}/action_decoder.pt" 
    center_crop: bool = True                         # Center crop? (if trained w/ random crop image aug)
    save_video: bool = True                         # Whether to save rollout videos

    #################################################################################################################
    # LIBERO environment-specific parameters
    #################################################################################################################
    task_suite_name: str = f"libero_{model_name}"               # Task suite. Options: libero_spatial, libero_object, libero_goal, libero_10, libero_90
    action_unnorm_key: str = f"libero_{model_name}"
    num_steps_wait: int = 10                         # Number of steps to wait for objects to stabilize in sim
    num_trials_per_task: int = 5                    # Number of rollouts per task
    window_size: int = 12

    ###############################################################################################################
    # Utils
    #################################################################################################################
    run_id_note: Optional[str] = None                # Extra note to add in run ID for logging
    local_log_dir: str = "./experiments/eval_logs"   # Local directory for eval logs
    use_wandb: bool = False                          # Whether to also log results in Weights & Biases
    wandb_project: str = "YOUR_WANDB_PROJECT"        # Name of W&B project to log to (use default!)
    wandb_entity: str = "YOUR_WANDB_ENTITY"          # Name of entity to log under

    seed: int = 7                                    # Random Seed (for reproducibility)


from prismatic.models.policy.transformer_utils import MAPBlock


class MLPResNetBlock(nn.Module):
