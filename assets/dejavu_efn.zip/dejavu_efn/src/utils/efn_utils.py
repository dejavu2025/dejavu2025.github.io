# -*- coding: utf-8 -*-
"""
Utility helpers for EFN SAC training:
- checkpoint save/rotate
- CSV logger init & append
- sliding-window stats
- simple convergence checks

Author: EFN
"""
from __future__ import annotations
import os
import csv
import json
import random
import numpy as np
from collections import deque
from typing import Dict, Optional, Any, Iterable
import torch
from experiments.robot.openvla_utils import DEVICE, OPENVLA_V01_SYSTEM_PROMPT
from PIL import Image
import torch.nn.functional as F

# -----------------------------
# FS helpers
# -----------------------------
def safe_mkdir(path: str):
    os.makedirs(path, exist_ok=True)

def save_checkpoint(path: str, state: Dict[str, Any], keep_last_k: int = 0):
    """
    Save a checkpoint and optionally keep only the latest K .pt files
    in the same directory (alphabetical order → oldest first).
    """
    d = os.path.dirname(path)
    safe_mkdir(d)
    torch.save(state, path)

    if keep_last_k > 0:
        files = [x for x in os.listdir(d) if x.endswith(".pt")]
        files.sort()
        while len(files) > keep_last_k:
            old = files.pop(0)
            try:
                os.remove(os.path.join(d, old))
            except Exception:
                pass

# -----------------------------
# Logging: CSV
# -----------------------------
CSV_HEADER = [
    "global_step", "epoch",
    "loss_q", "loss_pi", "loss_alpha", "alpha",
    "avg_reward_100", "success_rate_10",
    "q_mean", "td_err_abs", "entropy_gap"
]

def init_csv_logger(log_dir: str, filename: str = "metrics.csv") -> str:
    safe_mkdir(log_dir)
    path = os.path.join(log_dir, filename)
    if not os.path.exists(path):
        with open(path, "w", newline="") as f:
            csv.writer(f).writerow(CSV_HEADER)
    return path

def append_csv_row(path: str, row: Dict[str, Any]):
    vals = [row.get(k, 0.0) for k in CSV_HEADER]
    with open(path, "a", newline="") as f:
        csv.writer(f).writerow(vals)

# -----------------------------
# Sliding windows for metrics
# -----------------------------
class MetricWindows:
    def __init__(self, reward_len: int = 100, succ_len: int = 10, q_len: int = 200, td_len: int = 200):
        self.reward = deque(maxlen=reward_len)
        self.succ   = deque(maxlen=succ_len)
        self.q      = deque(maxlen=q_len)
        self.td     = deque(maxlen=td_len)

    def push_reward(self, r: float):
        self.reward.append(float(r))

    def push_succ(self, s: bool):
        self.succ.append(1.0 if s else 0.0)

    def push_q(self, q_scalar: float):
        self.q.append(float(q_scalar))

    def push_td(self, td_scalar: float):
        self.td.append(float(td_scalar))

    def mean_reward(self) -> float:
        return float(np.mean(self.reward)) if len(self.reward) else 0.0

    def mean_succ(self) -> float:
        return float(np.mean(self.succ)) if len(self.succ) else 0.0

    def mean_q(self) -> float:
        return float(np.mean(self.q)) if len(self.q) else 0.0

    def mean_td(self) -> float:
        return float(np.mean(self.td)) if len(self.td) else 0.0

# -----------------------------
# Simple convergence heuristics
# -----------------------------
def pct_change(a: float, b: float, eps: float = 1e-9) -> float:
    return abs(a - b) / (abs(b) + eps)

def looks_converged(entropy_gap: float,
                    target_entropy: float,
                    td_series: Iterable[float],
                    q_series: Iterable[float],
                    recent: int = 100) -> bool:
    """
    A lightweight rule:
      - |entropy_gap| < 5% of |target_entropy|
      - both TD abs error and Q mean have small pct changes (<2%) vs. earlier window
    """
    td_series = list(td_series)
    q_series  = list(q_series)
    if len(td_series) < 2 * recent or len(q_series) < 2 * recent:
        return False

    td_prev = float(np.mean(td_series[:recent]))
    td_now  = float(np.mean(td_series[-recent:]))
    q_prev  = float(np.mean(q_series[:recent]))
    q_now   = float(np.mean(q_series[-recent:]))

    ent_ok = abs(entropy_gap) < 0.05 * abs(target_entropy)
    plateau = (pct_change(td_now, td_prev) < 0.02) and (pct_change(q_now, q_prev) < 0.02)
    return ent_ok and plateau

# -----------------------------
# Seed helpers
# -----------------------------
def rng_state_dump() -> Dict[str, Any]:
    return {
        "python": random.getstate(),
        "numpy": np.random.get_state(),
        "torch": torch.get_rng_state(),
        "cuda": torch.cuda.get_rng_state_all(),
    }


# efn_utils.py
# efn_utils.py
class RunningNorm:
    def __init__(self, momentum: float = 0.002, eps: float = 1e-8,
                 gain: float = 8.0, clip: float = 4.0, var_floor: float = 1e-4):
        self.mu = 0.0
        self.var = 1e-2
        self.m = momentum
        self.eps = eps
        self.gain = gain
        self.clip = clip
        self.var_floor = var_floor
        self.inited = False

    def normalize(self, x: float) -> float:
        if not self.inited:
            z = 0.0
        else:
            std_old = max(self.var, self.var_floor) ** 0.5
            z = self.gain * ((x - self.mu) / (std_old + self.eps))
            z = float(np.clip(z, -self.clip, self.clip))

        if not self.inited:
            self.mu, self.var, self.inited = x, 1e-2, True
            return z

        mu_new = (1.0 - self.m) * self.mu + self.m * x
        res = x - mu_new
        var_new = (1.0 - self.m) * self.var + self.m * (res * res)

        self.mu = mu_new
        self.var = max(var_new, self.var_floor)

        return z

def to_sentence_vec_mean(lang_last, attention_mask=None, input_ids=None, tokenizer=None):
    if lang_last.dim() == 3:
        lang_last = lang_last[0]          # -> [L, H]
    L, H = lang_last.shape
    if attention_mask is None:
        mask = torch.ones(L, 1, dtype=lang_last.dtype, device=lang_last.device)
    else:
        if attention_mask.dim() == 2:
            attention_mask = attention_mask[0]
        mask = attention_mask[:L].unsqueeze(-1).to(lang_last.dtype)

    if tokenizer is not None and input_ids is not None:
        if input_ids.dim() == 2:
            input_ids = input_ids[0]
        bad_ids = set(
            tid for tid in [
                getattr(tokenizer, "pad_token_id", None),
                getattr(tokenizer, "bos_token_id", None),
                getattr(tokenizer, "eos_token_id", None),
                getattr(tokenizer, "cls_token_id", None),
                getattr(tokenizer, "sep_token_id", None),
            ] if tid is not None
        )
        if len(bad_ids):
            keep = ~torch.isin(input_ids[:L], torch.tensor(list(bad_ids), device=input_ids.device))
            mask = mask * keep.unsqueeze(-1).to(mask.dtype)

    sent = (lang_last * mask).sum(dim=0) / mask.sum(dim=0).clamp_min(1e-6)  # [H]
    return F.normalize(sent, p=2, dim=0)

def mean_pool(last_hidden: torch.Tensor, attention_mask: torch.Tensor):
    # last_hidden: [B, L, H]   attention_mask: [B, L]
    mask = attention_mask.unsqueeze(-1).type_as(last_hidden)  # [B, L, 1]
    summed = (last_hidden * mask).sum(dim=1)                  # [B, H]
    counts = mask.sum(dim=1).clamp_min(1e-6)                  # [B, 1]
    sent = summed / counts
    return F.normalize(sent, p=2, dim=-1)


@torch.no_grad()
def get_text_embeddings(
    vla, processor, base_vla_name: str, task_label: str
) -> Dict[str, torch.Tensor]:
    if "openvla-v01" in base_vla_name:  # OpenVLA v0.1
        prompt = (
            f"{OPENVLA_V01_SYSTEM_PROMPT} USER: What action should the robot take to {task_label.lower()}? ASSISTANT:"
        )
    else:  # OpenVLA
        prompt = f"In: What action should the robot take to {task_label.lower()}?\nOut:"
    image = Image.new("RGB", (1, 1), color=0)
    inputs = processor(prompt, image)
    input_ids = inputs["input_ids"].to(DEVICE)
    attn_mask = inputs.get("attention_mask", None)
    if attn_mask is not None:
        attn_mask = attn_mask.to(DEVICE)
    lang_out = vla(
        input_ids=input_ids,
        attention_mask=attn_mask,
        pixel_values=None,
        output_hidden_states=True,
        return_dict=True,
    )
    lang_last = lang_out.hidden_states[-1].to(torch.float32)  # [B, L, H]
    lang_feat = to_sentence_vec_mean(lang_last, attention_mask=attn_mask, input_ids=input_ids, tokenizer=processor.tokenizer)  # [H]
    return lang_feat