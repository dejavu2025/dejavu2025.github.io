"""
EFN: Language-Conditioned Similarity & Retrieval (Plug-and-Play, No Training)

This script provides:
  1) Pairwise similarity between two observations under a language instruction.
  2) Top‑K retrieval from an experience bank (JSONL of items with paths to saved features/images).

Signals supported (any subset works):
  • visual_embed: [256, H]  — per‑frame vision tokens from UniVLA
  • latent_action: [4, H]   — latent action tokens (optional, for phase alignment)
  • generated_ids: [4]      — discrete action IDs (optional, for hard filtering)
  • image: RGB image        — for language+vision rerank and relation features

Design (no training):
  • Stage A (coarse): visual_embed pooled to a compact vector u ∈ R^H.
      - If a text vector of same H is available, language‑weighted pooling is used.
      - Otherwise use language‑agnostic mean/max pooled fusion (robust fallback).
  • Stage B (rerank): CLIP image+text with optional OWL‑V2 open‑vocab detection
      to compute relation‑aware similarity (distance/contact/IoU), raising a>b>c.
  • Optional: latent_action cosine and generated_ids filtering to keep phase consistent.

CLI examples:
  Pairwise:
    python efn_sim_retriever.py pair \
      --obs1_img path/to/a.jpg --obs2_img path/to/b.jpg \
      --obs1_npz path/to/a.npz --obs2_npz path/to/b.npz \
      --lang "put the cup on the plate"

  Retrieval (experience bank):
    python efn_sim_retriever.py retrieve \
      --query_img path/to/q.jpg \
      --query_npz path/to/q.npz \
      --bank_jsonl path/to/bank.jsonl \
      --k 20 --lang "put the cup on the plate"

  Where each JSONL line in bank.jsonl may contain any of:
    {
      "id": "...",                      # unique key
      "image": "/abs/path/frame.jpg",  # optional but recommended for rerank
      "features": "/abs/path/item.npz"  # npz with keys: visual_embed, latent_action, generated_ids
    }

Dependencies:
    pip install torch torchvision pillow numpy transformers>=4.41.0 timm faiss-cpu

Notes:
- All components work without training. OWL‑V2 detector is optional; if model download
  fails, the reranker gracefully falls back to CLIP‑only.
- If your UniVLA exposes a text embedding in the SAME H as visual_embed, pass it via
  --obs*_text_npy for better language‑weighted pooling. Otherwise the code will use
  language‑agnostic pooling in Stage A and apply language in Stage B rerank.
"""

from __future__ import annotations

import os
import io
import sys
import math
import json
import argparse
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple
from tqdm import tqdm
import numpy as np
from PIL import Image

import torch
import torch.nn.functional as F

# Optional/slow imports guarded below
from transformers import (
    CLIPModel, CLIPProcessor,
)
try:
    from transformers import Owlv2ForObjectDetection, Owlv2Processor
    _HAVE_OWL = True
except Exception:
    _HAVE_OWL = False


# -----------------------------
# Utilities
# -----------------------------

def _to_pil(x: Any) -> Image.Image:
    """Convert input to PIL image (RGB)."""
    if x is None:
        raise ValueError("Image is None")
    if isinstance(x, Image.Image):
        return x.convert("RGB")
    if isinstance(x, np.ndarray):
        arr = x
        if arr.dtype != np.uint8:
            arr = np.clip(arr, 0, 255).astype(np.uint8)
        if arr.ndim == 2:
            arr = np.stack([arr] * 3, -1)
        if arr.shape[-1] == 4:
            arr = arr[..., :3]
        return Image.fromarray(arr)
    if torch.is_tensor(x):
        arr = x.detach().cpu().numpy()
        if arr.ndim == 3 and arr.shape[0] in (1, 3):
            arr = np.transpose(arr, (1, 2, 0))
        return _to_pil(arr)
    if isinstance(x, (str, os.PathLike)):
        return Image.open(x).convert("RGB")
    raise TypeError(f"Unsupported image type: {type(x)}")


def _cos01(a: torch.Tensor, b: torch.Tensor) -> float:
    """Cosine similarity mapped to [0,1]."""
    a = F.normalize(a.float(), dim=-1)
    b = F.normalize(b.float(), dim=-1)
    v = torch.sum(a * b, dim=-1).item()
    return 0.5 * (v + 1.0)


def _rbf_sim(v1: np.ndarray, v2: np.ndarray, sigmas: np.ndarray) -> float:
    """Radial basis function similarity for relation vectors."""
    v1 = np.asarray(v1, np.float32)
    v2 = np.asarray(v2, np.float32)
    sig = np.asarray(sigmas, np.float32) + 1e-6
    d2 = ((v1 - v2) ** 2) / (2.0 * sig ** 2)
    return float(np.clip(np.exp(-float(np.sum(d2))), 0.0, 1.0))


# -----------------------------
# Config
# -----------------------------

@dataclass
class Config:
    device: str = "cuda" if torch.cuda.is_available() else "cpu"
    clip_name: str = "openai/clip-vit-large-patch14"
    use_detector: bool = True
    det_thresh: float = 0.25

    # Fusion weights
    w_embed: float = 0.6
    w_image: float = 0.3
    w_act: float = 0.1

    # Relation RBF sigmas: [proximity, iou, contact, gripper_open]
    rel_sigmas: Tuple[float, float, float, float] = (0.15, 0.20, 0.25, 0.20)


# -----------------------------
# Models
# -----------------------------

class Models:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.clip = CLIPModel.from_pretrained(cfg.clip_name).to(cfg.device).eval()
        self.clip_proc: Optional[CLIPProcessor] = None
        self.det: Optional[Any] = None
        self.det_proc: Optional[Any] = None

        if cfg.use_detector and _HAVE_OWL:
            try:
                name = "google/owlv2-base-patch16-ensemble"
                self.det = Owlv2ForObjectDetection.from_pretrained(name).to(cfg.device).eval()
                self.det_proc = Owlv2Processor.from_pretrained(name)
            except Exception:
                self.det = None
                self.det_proc = None

    def clip_processor(self):
        if self.clip_proc is None:
            self.clip_proc = CLIPProcessor.from_pretrained(self.cfg.clip_name)
        return self.clip_proc


# -----------------------------
# Stage A: visual_embed pooling (coarse)
# -----------------------------

def pool_visual_embed(V: np.ndarray, text_h: Optional[np.ndarray] = None, beta: float = 10.0) -> np.ndarray:
    """Pool visual_embed [T,H] to u [H]. If text_h provided with same H, do language‑weighted pooling.
    Otherwise fall back to mean+max pooled fusion.
    """
    assert V.ndim == 2, f"visual_embed must be [T,H], got {V.shape}"
    T, H = V.shape
    Vt = torch.from_numpy(V).float()
    Vt = F.normalize(Vt, dim=-1)

    if text_h is not None and text_h.shape == (H,):
        t = torch.from_numpy(text_h).float()
        t = F.normalize(t, dim=-1)
        att = (Vt @ t) * beta  # [T]
        alpha = torch.softmax(att, dim=0).unsqueeze(-1)  # [T,1]
        u = torch.sum(alpha * Vt, dim=0)
    else:
        mean = Vt.mean(dim=0)
        mx, _ = Vt.max(dim=0)
        u = F.normalize(mean, dim=-1) * 0.5 + F.normalize(mx, dim=-1) * 0.5

    u = F.normalize(u, dim=-1)
    return u.cpu().numpy()


# -----------------------------
# Stage B: image+language reranker with optional relations
# -----------------------------

_VERB_MAP = {
    "grasp": ["robot gripper", "hand", "gripper", "cup", "mug", "plate", "bowl"],
    "pick":  ["robot gripper", "hand", "gripper", "cup", "mug", "plate", "bowl"],
    "place": ["robot gripper", "cup", "mug", "plate", "bowl", "tray"],
    "put":   ["robot gripper", "cup", "mug", "plate", "bowl", "tray"],
    "open":  ["robot gripper", "fridge", "fridge handle", "door handle"],
    "close": ["robot gripper", "fridge", "fridge handle", "door handle"],
    "press": ["robot gripper", "button", "switch"],
}


def _objects_for(language: str) -> List[str]:
    """Heuristic to get object queries for OWL‑V2 detection from language."""
    L = language.lower()
    for k in sorted(_VERB_MAP.keys(), key=len, reverse=True):
        if k in L:
            base = list(_VERB_MAP[k])
            # heuristic noun mining
            toks = [t.strip(",.!?;") for t in L.split()]
            nouns = [t for t in toks if t not in {"the","a","an","to","on","in","into","and","of","with","at","from"} and len(t) > 2]
            out = list(dict.fromkeys(base + nouns))
            return out[:12]
    return ["robot gripper", "hand", "gripper", "object", "cup", "plate", "bowl", "drawer", "fridge"]


def clip_embed(models: Models, img: Image.Image, text: Optional[str] = None) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
    """Get CLIP embeddings for image and optional text."""
    proc = models.clip_processor()(images=img, text=[text] if text else None, return_tensors="pt", padding=True)
    proc = {k: v.to(models.cfg.device) for k, v in proc.items()}
    with torch.no_grad():
        zi = models.clip.get_image_features(**{k: proc[k] for k in list(proc.keys()) if k in ("pixel_values",)})
        zi = F.normalize(zi, dim=-1).squeeze(0)
        if text is not None:
            zt = models.clip.get_text_features(**{k: proc[k] for k in ("input_ids","attention_mask")})
            zt = F.normalize(zt, dim=-1).squeeze(0)
        else:
            zt = None
    return zi, zt


def detect_owl(models: Models, img: Image.Image, queries: List[str], thresh: float) -> List[Dict[str, Any]]:
    """Run OWL‑V2 open‑vocab detection and return bounding boxes."""
    if models.det is None or models.det_proc is None:
        return []
    proc = models.det_proc(text=[queries], images=img, return_tensors="pt")
    proc = {k: v.to(models.cfg.device) for k, v in proc.items()}
    with torch.no_grad():
        out = models.det(**proc)
    target_sizes = torch.tensor([img.size[::-1]], device=models.cfg.device)
    post = models.det_proc.post_process_object_detection(out, target_sizes=target_sizes)[0]
    boxes = post["boxes"].cpu().numpy()
    scores = post["scores"].cpu().numpy()
    labels = post["labels"].cpu().numpy()
    dets = []
    for b, s, l in zip(boxes, scores, labels):
        if float(s) < thresh:
            continue
        dets.append({"bbox": b.astype(np.float32), "score": float(s), "label": queries[int(l)]})
    return dets


def _center(b: np.ndarray) -> Tuple[float, float]:
    x1, y1, x2, y2 = b
    return (0.5 * (x1 + x2), 0.5 * (y1 + y2))


def _iou(a: np.ndarray, b: np.ndarray) -> float:
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    iw, ih = max(0.0, ix2 - ix1), max(0.0, iy2 - iy1)
    inter = iw * ih
    area_a = max(0.0, (ax2 - ax1) * (ay2 - ay1))
    area_b = max(0.0, (bx2 - bx1) * (by2 - by1))
    union = area_a + area_b - inter + 1e-6
    return float(np.clip(inter / union, 0.0, 1.0))


def rel_features(img: Image.Image, language: str, dets: List[Dict[str, Any]], obs_meta: Optional[Dict[str, Any]]) -> Tuple[np.ndarray, Dict[str, Any]]:
    """Compute relation features (distance, IoU, contact, gripper_open)."""
    W, H = img.size
    diag = math.sqrt(W * W + H * H) + 1e-6

    L = language.lower()
    if any(k in L for k in ["cup","mug","plate","bowl","tray","dish"]):
        obj_keywords = ["cup", "mug", "plate", "bowl", "tray", "dish"]
    elif any(k in L for k in ["fridge","door","handle"]):
        obj_keywords = ["fridge handle", "door handle", "fridge", "door"]
    else:
        obj_keywords = ["object", "target"]

    grip, targ = None, None
    for d in sorted(dets, key=lambda x: -x["score"]):
        lbl = d["label"].lower()
        if grip is None and any(k in lbl for k in ["gripper", "hand"]):
            grip = d
        if targ is None and any(k in lbl for k in obj_keywords):
            targ = d
        if grip is not None and targ is not None:
            break

    dist_norm, iou, contact = 0.5, 0.0, 0.0
    have_grip = grip is not None
    have_targ = targ is not None

    if have_grip and have_targ:
        gc = _center(grip["bbox"])
        tc = _center(targ["bbox"])
        dist = math.dist(gc, tc)
        dist_norm = float(np.clip(dist / diag, 0.0, 1.0))
        iou = _iou(grip["bbox"], targ["bbox"])
        contact = float(np.clip(max(iou, 1.0 - 3.0 * dist_norm), 0.0, 1.0))

    gripper_open = 0.5
    if obs_meta and isinstance(obs_meta, dict) and (go := obs_meta.get("gripper_opening")) is not None:
        gripper_open = float(np.clip(go / 40.0, 0.0, 1.0)) if go > 1.5 else float(np.clip(go, 0.0, 1.0))

    vec = np.array([1.0 - dist_norm, iou, contact, gripper_open], dtype=np.float32)
    detail = {
        "have_gripper": have_grip,
        "have_target": have_targ,
        "proximity": 1.0 - dist_norm,
        "iou": iou,
        "contact": contact,
        "gripper_open": gripper_open,
    }
    return vec, detail


def image_language_score(models: Models, img1: Image.Image, img2: Image.Image, language: str, obs1_meta=None, obs2_meta=None) -> Tuple[float, Dict[str, Any]]:
    """Compute rerank score between two images under language."""
    z1, _ = clip_embed(models, img1, None)
    z2, _ = clip_embed(models, img2, None)
    # get text embedding once on first image
    t_emb = clip_embed(models, img1, language)[1]

    sim_clip = _cos01(z1, z2)
    sim_text = min(_cos01(z1, t_emb), _cos01(z2, t_emb))

    sim_rel = 0.5
    rel_detail = {"used": False}

    if models.det is not None and models.det_proc is not None:
        queries = _objects_for(language)
        d1 = detect_owl(models, img1, queries, models.cfg.det_thresh)
        d2 = detect_owl(models, img2, queries, models.cfg.det_thresh)
        r1, d1d = rel_features(img1, language, d1, obs1_meta)
        r2, d2d = rel_features(img2, language, d2, obs2_meta)
        sim_rel = _rbf_sim(r1, r2, np.array(models.cfg.rel_sigmas, np.float32))
        rel_detail = {
            "used": True,
            "queries": queries,
            "obs1": d1d,
            "obs2": d2d,
            "r1": r1.tolist(),
            "r2": r2.tolist(),
        }

    # fuse image+text+rel to a single rerank score (normalized weights)
    w = np.array([0.5, 0.2, 0.3], np.float32)
    if not rel_detail["used"]:
        w = np.array([0.5, 0.5, 0.0], np.float32)
    w = w / (w.sum() + 1e-6)
    rerank = float(np.clip(w[0] * sim_clip + w[1] * sim_text + w[2] * sim_rel, 0.0, 1.0))

    return rerank, {
        "sim_clip": sim_clip,
        "sim_text": sim_text,
        "sim_rel": sim_rel,
        "rel_detail": rel_detail,
    }


# -----------------------------
# End‑to‑end similarity
# -----------------------------

@dataclass
class ObsPack:
    image: Optional[Image.Image] = None
    visual_embed: Optional[np.ndarray] = None  # [T,H]
    latent_action: Optional[np.ndarray] = None # [4,H]
    generated_ids: Optional[np.ndarray] = None # [4]
    meta: Optional[Dict[str, Any]] = None     # e.g., {gripper_opening: ...}
    text_h: Optional[np.ndarray] = None        # language vector in same H (optional)


class EFNSim:
    def __init__(self, cfg: Optional[Config] = None):
        self.cfg = cfg or Config()
        self.models = Models(self.cfg)

    def score_pair(self, a: ObsPack, b: ObsPack, language: str, lambda_embed: Optional[float] = None) -> Dict[str, Any]:
        """Compute final similarity score between two observation packs under a language instruction."""
        # Stage A: visual_embed coarse
        S_embed, u_a, u_b = 0.0, None, None
        if a.visual_embed is not None and b.visual_embed is not None:
            u_a = pool_visual_embed(a.visual_embed, a.text_h)
            u_b = pool_visual_embed(b.visual_embed, b.text_h)
            S_embed = float(_cos01(torch.from_numpy(u_a), torch.from_numpy(u_b)))

        # Stage B: image rerank
        S_img, img_detail = 0.0, {}
        if a.image is not None and b.image is not None:
            S_img, img_detail = image_language_score(self.models, a.image, b.image, language, a.meta, b.meta)

        # Optional: latent action alignment
        S_act = 0.0
        if a.latent_action is not None and b.latent_action is not None:
            la = torch.from_numpy(a.latent_action).float().mean(dim=0)
            lb = torch.from_numpy(b.latent_action).float().mean(dim=0)
            S_act = float(_cos01(la, lb))

        # Optional: hard filter by generated_ids equality (if desired)
        hard_penalty = 0.0
        if a.generated_ids is not None and b.generated_ids is not None:
            same = bool(np.array_equal(a.generated_ids, b.generated_ids))
            hard_penalty = 0.0 if same else 0.0  # set to negative value if you want to penalize mismatch

        # Fuse
        w_embed, w_image, w_act = self.cfg.w_embed, self.cfg.w_image, self.cfg.w_act
        if lambda_embed is not None:
            w_embed = lambda_embed
            # renormalize others proportionally
            rest = max(1.0 - w_embed, 0.0)
            total = self.cfg.w_image + self.cfg.w_act + 1e-6
            w_image = rest * (self.cfg.w_image / total)
            w_act = rest * (self.cfg.w_act / total)

        # If some channels missing, re‑normalize existing weights
        comp = []
        weights = []
        if a.visual_embed is not None and b.visual_embed is not None:
            comp.append(S_embed); weights.append(w_embed)
        if a.image is not None and b.image is not None:
            comp.append(S_img);   weights.append(w_image)
        if a.latent_action is not None and b.latent_action is not None:
            comp.append(S_act);   weights.append(w_act)
        if not weights:
            raise ValueError("At least one of visual_embed/image/latent_action must be provided for BOTH obs.")
        weights = np.array(weights, np.float32)
        weights = weights / (weights.sum() + 1e-6)
        S = float(np.clip(float(np.dot(weights, np.array(comp, np.float32))) + hard_penalty, 0.0, 1.0))

        return {
            "score": S,
            "components": {
                "S_embed": S_embed,
                "S_image": S_img,
                "S_action": S_act,
                "weights": {
                    "w_embed": float(weights[0]) if len(weights) > 0 else 0.0,
                    "w_image": float(weights[1]) if len(weights) > 1 else 0.0,
                    "w_action": float(weights[2]) if len(weights) > 2 else 0.0,
                },
                "image_detail": img_detail,
            },
            "u_a": u_a.tolist() if u_a is not None else None,
            "u_b": u_b.tolist() if u_b is not None else None,
        }

    # Retrieval over a bank of items
    def topk(self, query: ObsPack, bank: List[ObsPack], language: str, k: int = 20) -> List[Tuple[int, float]]:
        """Return top-K indices and scores from bank for the query observation."""
        scores = []
        for i, item in enumerate(bank):
            out = self.score_pair(query, item, language)
            scores.append((i, out["score"]))
        scores.sort(key=lambda x: x[1], reverse=True)
        return scores[:k]


# -----------------------------
# IO helpers for bank JSONL
# -----------------------------

def load_npz_features(path: str) -> Dict[str, Any]:
    """Load features from npz file."""
    with np.load(path, allow_pickle=True) as f:
        out: Dict[str, Any] = {}
        for k in ("visual_embed", "latent_action", "generated_ids"):
            if k in f:
                out[k] = f[k]
        return out


def load_obspack(image_path: Optional[str], feature_path: Optional[str]) -> ObsPack:
    """Create ObsPack from image and npz feature file."""
    img = _to_pil(image_path) if image_path else None
    feats = load_npz_features(feature_path) if feature_path else {}
    return ObsPack(
        image=img,
        visual_embed=feats.get("visual_embed"),
        latent_action=feats.get("latent_action"),
        generated_ids=feats.get("generated_ids"),
        meta=None,
        text_h=None,
    )

def read_bank_jsonl(path: str) -> Tuple[List[ObsPack], List[Dict[str, Any]]]:
    """Read bank JSONL and return list of ObsPacks and raw dicts."""
    items: List[ObsPack] = []
    raws: List[Dict[str, Any]] = []
    with open(path, "r", encoding="utf-8") as fh:
        for line in tqdm(fh, desc="Reading bank"):
            if not line.strip():
                continue
            obj = json.loads(line)
            raws.append(obj)
            items.append(load_obspack(obj.get("image"), obj.get("features")))
    return items, raws





# -----------------------------
# CLI
# -----------------------------

def main():
    p = argparse.ArgumentParser(description="EFN Similarity & Retrieval (no training)")
    sub = p.add_subparsers(dest="cmd", required=True)

    # pairwise
    pp = sub.add_parser("pair", help="pairwise similarity")
    pp.add_argument("--lang", required=True, help="Language instruction")
    pp.add_argument("--obs1_img", type=str, help="Path to observation 1 image")
    pp.add_argument("--obs2_img", type=str, help="Path to observation 2 image")
    pp.add_argument("--obs1_npz", type=str, help="Path to observation 1 .npz features")
    pp.add_argument("--obs2_npz", type=str, help="Path to observation 2 .npz features")
    pp.add_argument("--lambda_embed", type=float, default=None, help="Override weight for visual embed component")
    pp.add_argument("--no_detector", action="store_true", help="Disable OWL‑V2 detector")

    # retrieve
    pr = sub.add_parser("retrieve", help="top‑K retrieval over a bank")
    pr.add_argument("--lang", required=True, help="Language instruction")
    pr.add_argument("--query_img", type=str, help="Path to query image")
    pr.add_argument("--query_npz", type=str, help="Path to query .npz features")
    pr.add_argument("--bank_jsonl", required=True, help="Path to bank JSONL file")
    pr.add_argument("--k", type=int, default=20, help="Number of top results to return")
    pr.add_argument("--no_detector", action="store_true", help="Disable OWL‑V2 detector")

    args = p.parse_args()

    cfg = Config()
    if args.cmd == "pair":
        if args.no_detector:
            cfg.use_detector = False
        eng = EFNSim(cfg)
        A = load_obspack(args.obs1_img, args.obs1_npz)
        B = load_obspack(args.obs2_img, args.obs2_npz)
        out = eng.score_pair(A, B, args.lang, lambda_embed=args.lambda_embed)
        print(json.dumps(out, indent=2))

    elif args.cmd == "retrieve":
        if args.no_detector:
            cfg.use_detector = False
        eng = EFNSim(cfg)
        Q = load_obspack(args.query_img, args.query_npz)
        bank, raws = read_bank_jsonl(args.bank_jsonl)
        top = eng.topk(Q, bank, args.lang, k=args.k)
        # pretty print with metadata
        result = [
            {"rank": i + 1, "bank_idx": idx, "score": float(s), **raws[idx]} for i, (idx, s) in enumerate(top)
        ]
        ret = json.dumps({"results": result}, indent=2)
        print(ret)


if __name__ == "__main__":
    main()