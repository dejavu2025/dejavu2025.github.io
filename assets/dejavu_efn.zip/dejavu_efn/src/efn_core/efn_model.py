# efn_model.py
# -*- coding: utf-8 -*-

from typing import Optional, Tuple
import torch
import torch.nn as nn
import torch.nn.functional as F

try:
    from prismatic.models.policy.transformer_utils import MAPBlock
except Exception as e:
    raise ImportError(
        "无法导入 MAPBlock，请确认 efn_model.py 位于 UniVLA 项目可被 sys.path 找到的位置。\n"
        f"原始错误: {e}"
    )


# -------------------------
# -------------------------

class LayerNormFp32(nn.LayerNorm):
    Query:   当前 4 个 latent token
    Context: [当前视觉池化(4个) + 经验视觉池化(4个) + 经验 latent(4个)]  共 12 个上下文 token
    Cross-Attn -> Tiny Transformer -> Δlatent
    简单的值函数：聚合四路信息，估计状态价值。
    结构：当前/经验各做 1 个视觉 MAP latent，当前/经验 latent 做均值，再拼接 MLP。
    提供三个便捷接口：
    - compute_residual(latent_cur, visual_cur, latent_exp, visual_exp) -> residual
    - refine_latent(latent_cur, visual_cur, latent_exp, visual_exp) -> latent_cur + residual
    - forward(...) -> (residual, value)
