# EFN (Experience Feedback Network)

This repository contains a beta version implementation of the **Experience Feedback Network (EFN)** used in our ICLR 2026 submission “Dejavu: Post‑Deployment Learning via Experience Feedback”. EFN augments a frozen VLA policy with an experience‑guided residual controller trained with SAC.

## Structure

```
efn_beta/
├── src/
│   ├── efn_core/       # Core EFN modules (residual head, networks, decoding glue)
│   ├── retrieval/      # Language‑conditioned similarity, pooled keys, Sinkhorn utils
│   ├── memory/         # Experience bank schema, storage, compaction
│   ├── training/       # SAC loops, losses, replay, metrics
│   ├── envs/           # Env adapters (LIBERO, real robot), safety wrappers
│   └── utils/          # I/O, logging, config, small helpers
├── scripts/
│   ├── train/          # Train entry points (e.g., train_efn_sac.py)
│   ├── eval/           # Evaluation / rollout drivers
│   └── tools/          # Data prep, converters, misc utilities
├── configs/            # YAML/JSON configs
├── assets/             # Small static assets (figs, tables)
├── notebooks/          # Optional analysis
└── tests/              # Unit & smoke tests
```

## Quick start

1) Create an environment:
```bash
conda create -n efn python=3.10 -y
conda activate efn
pip install -r requirements.txt
```

2) Train EFN on LIBERO with a frozen VLA backbone:
```bash
python scripts/train/train_efn_sac.py   --config configs/libero_openvla_efn.yaml   --bank_dir /path/to/bank   --log_dir  /path/to/logs
```

3) Evaluate with a prebuilt experience bank:
```bash
python scripts/eval/eval_rollout.py   --config configs/libero_openvla_efn.yaml   --bank_dir /path/to/bank   --episodes 50
```

### Notes

- The code expects a frozen VLA policy (e.g., OpenVLA/UniVLA); only EFN modules train.
- Experience bank stores pooled visual keys and step‑level tuples for fast retrieval.

